#!/usr/bin/env python3
"""
Bug Hunter Swiss Knife v4.0 - Professional Edition
31 Modules | Complete Bug Bounty Toolkit
"""

import os
import sys
import json
from datetime import datetime
from colorama import init, Fore, Style

init(autoreset=True)

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_banner():
    print(f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════╗
║                                                      ║
║     {Fore.RED}🐛  BUG HUNTER SWISS KNIFE v4.0  🐛{Fore.CYAN}            ║
║     {Fore.YELLOW}   Professional Bug Bounty Toolkit{Fore.CYAN}            ║
║     {Fore.GREEN}        31 Modules | All-in-One{Fore.CYAN}              ║
║                                                      ║
╚══════════════════════════════════════════════════════╝{Style.RESET_ALL}
    
{Fore.RED}⚠️  WARNING: Use only on authorized targets!{Style.RESET_ALL}
    """)

def get_user_input(prompt, default=None):
    try:
        if default:
            return input(f"\n{Fore.YELLOW}[?] {prompt} [{default}]: {Style.RESET_ALL}").strip() or default
        return input(f"\n{Fore.YELLOW}[?] {prompt}: {Style.RESET_ALL}").strip()
    except KeyboardInterrupt:
        return None

def get_url_input():
    while True:
        url = get_user_input("Enter target URL")
        if url is None: return None
        if url.startswith(('http://', 'https://')): return url
        print(f"{Fore.RED}[✗] Invalid URL!{Style.RESET_ALL}")

def build_config():
    print(f"\n{Fore.CYAN}[*] Advanced Options (press Enter to skip){Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'─'*40}{Style.RESET_ALL}")
    cookies = get_user_input("Cookies (name=value; name2=value2)")
    delay = get_user_input("Delay between requests (seconds)", "0")
    proxy = get_user_input("Proxy (e.g., http://127.0.0.1:8080)")
    user_agent = get_user_input("Custom User-Agent")
    custom_headers = get_user_input("Custom headers (Key:Value, comma separated)")
    verbose = get_user_input("Verbose output? (y/n)", "y").lower() == 'y'
    headers = {}
    if cookies: headers['Cookie'] = cookies
    if user_agent: headers['User-Agent'] = user_agent
    if custom_headers:
        for h in custom_headers.split(','):
            if ':' in h:
                k, v = h.split(':', 1)
                headers[k.strip()] = v.strip()
    return {'headers': headers, 'delay': float(delay) if delay else 0, 'proxy': proxy if proxy else None, 'verbose': verbose}

def press_enter():
    input(f"\n{Fore.CYAN}[*] Press Enter to continue...{Style.RESET_ALL}")

# ==================== MODULE 1-10: CORE ====================

def crawl_module():
    from modules.crawler import WebCrawler
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[1] 🕷️ WEB CRAWLER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    depth = int(get_user_input("Crawl depth", "3"))
    max_urls = int(get_user_input("Max URLs", "1000"))
    config = build_config()
    try:
        crawler = WebCrawler(url=url, max_depth=depth, max_urls=max_urls, config=config)
        endpoints = crawler.crawl()
        if endpoints:
            print(f"\n{Fore.GREEN}[✓] {len(endpoints)} endpoints{Style.RESET_ALL}")
            for i, ep in enumerate(endpoints[:20], 1): print(f"  {i}. {ep}")
    except Exception as e: print(f"\n{Fore.RED}[✗] {e}{Style.RESET_ALL}")
    press_enter()

def scanner_module():
    from modules.scanner import VulnScanner
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[2] 🔍 VULNERABILITY SCANNER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    print(f"\n[1] XSS  [2] SQLi  [3] Redirect  [4] All")
    test_map = {'1':'xss','2':'sqli','3':'redirect','4':'all'}
    test_type = test_map.get(get_user_input("Choice", "4"), 'all')
    config = build_config()
    try:
        scanner = VulnScanner(url=url, test_type=test_type, config=config)
        vulns = scanner.scan()
        if vulns:
            print(f"\n{Fore.RED}[!] Vulnerabilities:{Style.RESET_ALL}")
            for v in vulns: print(f"  {v}")
    except Exception as e: print(f"\n{Fore.RED}[✗] {e}{Style.RESET_ALL}")
    press_enter()

def port_scanner_module():
    from modules.network import NetworkScanner
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[3] 🌐 PORT SCANNER{Style.RESET_ALL}")
    host = get_user_input("IP/Hostname", "127.0.0.1")
    if not host: return
    print(f"\n[1] Quick  [2] Full  [3] Common  [4] Custom")
    rc = get_user_input("Choice", "1")
    if rc=='1': sp,ep=1,1000
    elif rc=='2': sp,ep=1,10000
    elif rc=='3': sp,ep=1,1000
    elif rc=='4': sp=int(get_user_input("Start","1")); ep=int(get_user_input("End","1000"))
    else: sp,ep=1,1000
    threads = int(get_user_input("Threads","100"))
    verbose = get_user_input("Verbose?","y").lower()=='y'
    scanner = NetworkScanner(host=host, port_range=(sp,ep), config={'threads':threads,'verbose':verbose})
    scanner.scan()
    press_enter()

def tech_detector_module():
    from modules.tech_detector import TechDetector
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[4] 🔬 TECHNOLOGY DETECTOR{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    config = build_config()
    detector = TechDetector(url, config)
    detector.detect(); detector.display_results()
    press_enter()

def sensitive_files_module():
    from modules.sensitive_files import SensitiveFileFinder
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[5] 🗂️ SENSITIVE FILES{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    config = build_config()
    finder = SensitiveFileFinder(url, config)
    finder.scan(); finder.display_results()
    press_enter()

def dir_bruteforce_module():
    from modules.dir_bruteforcer import DirBruteforcer
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[6] 📂 DIRECTORY BRUTEFORCER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    threads = int(get_user_input("Threads","20"))
    config = build_config()
    bruteforcer = DirBruteforcer(url, threads=threads, config=config)
    bruteforcer.scan(); bruteforcer.display_results()
    press_enter()

def waf_detector_module():
    from modules.waf_detector import WAFDetector
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[7] 🛡️ WAF DETECTOR{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    config = build_config()
    detector = WAFDetector(url, config)
    detector.detect(); detector.display_results()
    press_enter()

def full_audit_module():
    from modules.crawler import WebCrawler
    from modules.scanner import VulnScanner
    from modules.tech_detector import TechDetector
    from modules.sensitive_files import SensitiveFileFinder
    from modules.waf_detector import WAFDetector
    from modules.reporter import ReportGenerator
    from modules.discord_notifier import DiscordNotifier
    
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[8] 🚀 FULL AUDIT{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    depth = int(get_user_input("Crawl depth","2"))
    config = build_config()
    report_name = get_user_input("Report filename", f"audit_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html")
    discord_webhook = get_user_input("Discord Webhook URL (optional)")
    
    results = {'scan_info':{'timestamp':datetime.now().isoformat(),'command':f'Full Audit: {url}'},'endpoints':[],'vulnerabilities':[],'open_ports':[],'technologies':{},'sensitive_files':[],'directories':[],'waf':None}
    
    if discord_webhook:
        notifier = DiscordNotifier(discord_webhook, {'verbose':config['verbose']})
        notifier.send_scan_start(url, ['Crawl','Vuln Scan','Tech Detect','Sensitive Files'])
    
    try:
        print(f"\n{Fore.CYAN}[1/5] WAF...{Style.RESET_ALL}")
        waf = WAFDetector(url, config); results['waf'] = waf.detect()
        print(f"\n{Fore.CYAN}[2/5] Tech...{Style.RESET_ALL}")
        tech = TechDetector(url, config); results['technologies'] = tech.detect()
        print(f"\n{Fore.CYAN}[3/5] Crawl...{Style.RESET_ALL}")
        crawler = WebCrawler(url=url, max_depth=depth, max_urls=500, config=config)
        results['endpoints'] = crawler.crawl()
        print(f"\n{Fore.CYAN}[4/5] Files...{Style.RESET_ALL}")
        finder = SensitiveFileFinder(url, config); results['sensitive_files'] = finder.scan()
        print(f"\n{Fore.CYAN}[5/5] Vulns...{Style.RESET_ALL}")
        for ep in [e for e in results['endpoints'] if '?' in e][:10]:
            scanner = VulnScanner(url=ep, test_type='all', config=config)
            vulns = scanner.scan()
            if vulns: results['vulnerabilities'].extend([f"[{ep}] {v}" for v in vulns if 'No vulnerabilities' not in v])
        
        json_file = ReportGenerator.save_scan_data(results)
        reporter = ReportGenerator(results); reporter.generate_html(report_name)
        print(f"\n{Fore.GREEN}[✓] Done! JSON: {json_file} | Report: {report_name}{Style.RESET_ALL}")
        if discord_webhook:
            notifier.send_scan_complete(url, results)
            notifier.send_file(report_name, "📊 Scan Report")
    except Exception as e: print(f"\n{Fore.RED}[✗] {e}{Style.RESET_ALL}")
    press_enter()

def report_menu():
    from modules.reporter import ReportGenerator
    from modules.pro_report import ProReportGenerator
    while True:
        clear_screen(); print_banner()
        print(f"\n{Fore.GREEN}[9] 📊 REPORT GENERATOR{Style.RESET_ALL}")
        print(f"  [1] From saved scan\n  [2] Manual entry\n  [3] Pro Report (Charts)\n  [4] View scans\n  [5] Delete\n  [0] Back")
        choice = get_user_input("Choice","0")
        if choice=='0': break
        elif choice=='1':
            scans = ReportGenerator.list_saved_scans()
            if scans:
                for i,s in enumerate(scans,1): print(f"  [{i}] {s['file']}")
                idx = int(get_user_input("Select","1"))-1
                if 0<=idx<len(scans):
                    data = ReportGenerator.load_scan_data(scans[idx]['filepath'])
                    if data:
                        rpt = get_user_input("Filename","report.html")
                        ReportGenerator(data).generate_html(rpt)
                        print(f"{Fore.GREEN}[✓] {rpt}{Style.RESET_ALL}")
        elif choice=='2':
            results = {'scan_info':{'timestamp':datetime.now().isoformat(),'command':'Manual'},'endpoints':[],'vulnerabilities':[],'open_ports':[],'technologies':{},'sensitive_files':[],'directories':[],'waf':None}
            print("Endpoints (empty to finish):")
            while True:
                ep = input("  → ").strip()
                if not ep: break
                results['endpoints'].append(ep)
            print("Vulns (empty to finish):")
            while True:
                v = input("  → ").strip()
                if not v: break
                results['vulnerabilities'].append(v)
            rpt = get_user_input("Filename","report.html")
            if rpt: ReportGenerator(results).generate_html(rpt)
        elif choice=='3':
            scans = ReportGenerator.list_saved_scans()
            if scans:
                for i,s in enumerate(scans,1): print(f"  [{i}] {s['file']}")
                idx = int(get_user_input("Select","1"))-1
                if 0<=idx<len(scans):
                    data = ReportGenerator.load_scan_data(scans[idx]['filepath'])
                    if data:
                        rpt = get_user_input("Filename","pro_report.html")
                        ProReportGenerator(data).generate_html(rpt)
                        print(f"{Fore.GREEN}[✓] {rpt}{Style.RESET_ALL}")
            else: print(f"{Fore.YELLOW}[!] No scans{Style.RESET_ALL}")
        elif choice=='4':
            scans = ReportGenerator.list_saved_scans()
            if scans:
                for s in scans: print(f"  • {s['file']} | {s['timestamp']}")
            else: print(f"{Fore.YELLOW}[!] No scans{Style.RESET_ALL}")
        elif choice=='5':
            scans = ReportGenerator.list_saved_scans()
            if scans:
                for i,s in enumerate(scans,1): print(f"  [{i}] {s['file']}")
                idx = int(get_user_input("Delete","1"))-1
                if 0<=idx<len(scans):
                    ReportGenerator.delete_scan_file(scans[idx]['filepath'])
                    print(f"{Fore.GREEN}[✓] Deleted{Style.RESET_ALL}")
        press_enter()

def auth_module():
    from modules.auth_handler import AuthHandler
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[10] 🔑 AUTH HANDLER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    auth = AuthHandler(url, {'verbose':True})
    try:
        import requests, urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        s = requests.Session(); s.verify=False; s.headers['User-Agent']='BugHunter/4.0'
        resp = s.get(url, timeout=10)
        if 'Set-Cookie' in resp.headers:
            auth.extracted_cookies = resp.headers['Set-Cookie'].split(';')[0].strip()
            print(f"{Fore.GREEN}[✓] Cookies: {auth.extracted_cookies}{Style.RESET_ALL}")
    except: pass
    while True:
        print(f"\n  [1] Register  [2] Login  [3] Session  [4] Get String  [5] Extract  [6] Logout  [0] Back")
        c = get_user_input("Choice","0")
        if c=='0': break
        elif c=='1':
            auth.register(get_user_input("Name","Test"),get_user_input("Email","test@test.com"),get_user_input("Phone","017"),get_user_input("Password","Test1234"),get_user_input("Role","buyer"))
            auth.login(get_user_input("Email","test@test.com"),get_user_input("Password","Test1234"))
        elif c=='2':
            s = auth.login(get_user_input("Email","test@test.com"),get_user_input("Password","Test1234"))
            if s:
                print(f"{Fore.GREEN}[✓] Logged in{Style.RESET_ALL}")
                ss = auth.get_session_string()
                if ss: print(f"{Fore.CYAN}{ss}{Style.RESET_ALL}")
        elif c=='3':
            s = auth.get_session()
            print(json.dumps(s, indent=2) if s else f"{Fore.YELLOW}[!] No session{Style.RESET_ALL}")
        elif c=='4':
            ss = auth.get_session_string()
            if ss: print(f"{Fore.CYAN}{ss}{Style.RESET_ALL}")
            if hasattr(auth,'extracted_cookies') and auth.extracted_cookies: print(f"{Fore.CYAN}{auth.extracted_cookies}{Style.RESET_ALL}")
        elif c=='5':
            eu = get_user_input("URL", url)
            if eu:
                try:
                    s = requests.Session(); s.verify=False
                    resp = s.get(eu, timeout=10)
                    ck = s.cookies.get_dict()
                    if ck: print(f"{Fore.GREEN}{'; '.join([f'{k}={v}' for k,v in ck.items()])}{Style.RESET_ALL}")
                except: pass
        elif c=='6': auth.logout(); print(f"{Fore.GREEN}[✓] Logged out{Style.RESET_ALL}")
        press_enter()

# ==================== MODULE 11-20: EXTENDED ====================

def subdomain_module():
    from modules.subdomain_finder import SubdomainFinder
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[11] 🌐 SUBDOMAIN FINDER{Style.RESET_ALL}")
    domain = get_user_input("Domain (e.g., example.com)")
    if not domain: return
    finder = SubdomainFinder(domain, threads=int(get_user_input("Threads","30")), config={'verbose':get_user_input("Verbose?","y").lower()=='y'})
    finder.scan(); finder.display_results()
    press_enter()

def header_analyzer_module():
    from modules.header_analyzer import HeaderAnalyzer
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[12] 🔒 HEADER ANALYZER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    analyzer = HeaderAnalyzer(url, build_config())
    analyzer.analyze(); analyzer.display_results()
    press_enter()

def js_analyzer_module():
    from modules.js_analyzer import JSAnalyzer
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[13] 🔍 JS SECRET FINDER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    analyzer = JSAnalyzer(url, build_config())
    analyzer.scan(); analyzer.display_results()
    press_enter()

def wayback_module():
    from modules.wayback import WaybackMachine
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[14] 📅 WAYBACK MACHINE{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    wayback = WaybackMachine(url, build_config())
    wayback.scan(); wayback.display_results()
    press_enter()

def email_harvester_module():
    from modules.email_harvester import EmailHarvester
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[15] 📧 EMAIL HARVESTER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    harvester = EmailHarvester(url, int(get_user_input("Depth","2")), build_config())
    harvester.harvest(); harvester.display_results()
    press_enter()

def wp_scanner_module():
    from modules.wp_scanner import WPScanner
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[16] 🎯 WORDPRESS SCANNER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    scanner = WPScanner(url, build_config())
    scanner.scan(); scanner.display_results()
    press_enter()

def sitemap_module():
    from modules.sitemap_parser import SitemapParser
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[17] 🗺️ SITEMAP PARSER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    parser = SitemapParser(url, build_config())
    parser.scan(); parser.display_results()
    press_enter()

def cors_scanner_module():
    from modules.cors_scanner import CORSScanner
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[18] 🔓 CORS SCANNER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    scanner = CORSScanner(url, build_config())
    scanner.scan(); scanner.display_results()
    press_enter()

def screenshot_module():
    from modules.screenshot import ScreenshotCapture
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[19] 📸 SCREENSHOT{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    capture = ScreenshotCapture(url, build_config())
    capture.capture(); capture.display_results()
    press_enter()

def link_checker_module():
    from modules.link_checker import LinkChecker
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[20] 🔗 LINK CHECKER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    checker = LinkChecker(url, build_config())
    checker.scan(); checker.display_results()
    press_enter()

# ==================== MODULE 21-28: ADVANCED ====================

def security_headers_module():
    from modules.security_headers import SecurityHeaders
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[21] 🔒 SECURITY HEADERS (Enhanced){Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    checker = SecurityHeaders(url, build_config())
    checker.scan(); checker.display_results()
    press_enter()

def dir_listing_module():
    from modules.dir_listing import DirListingChecker
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[22] 📂 DIR LISTING CHECK{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    checker = DirListingChecker(url, build_config())
    checker.scan(); checker.display_results()
    press_enter()

def open_redirect_module():
    from modules.open_redirect import OpenRedirectDetector
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[23] 🔀 OPEN REDIRECT{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    detector = OpenRedirectDetector(url, build_config())
    detector.scan(); detector.display_results()
    press_enter()

def subdomain_takeover_module():
    from modules.subdomain_takeover import SubdomainTakeover
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[24] 🌐 SUBDOMAIN TAKEOVER{Style.RESET_ALL}")
    domain = get_user_input("Subdomains (comma separated)")
    if not domain: return
    checker = SubdomainTakeover([s.strip() for s in domain.split(',')], build_config())
    checker.scan(); checker.display_results()
    press_enter()

def api_finder_module():
    from modules.api_finder import APIFinder
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[25] 🔌 API DISCOVERY{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    finder = APIFinder(url, build_config())
    finder.discover(); finder.display_results()
    press_enter()

def ssrf_checker_module():
    from modules.ssrf_checker import SSRFChecker
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[26] 🔴 SSRF CHECKER{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    checker = SSRFChecker(url, build_config())
    checker.scan(); checker.display_results()
    press_enter()

def idor_detector_module():
    from modules.idor_detector import IDORDetector
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[27] 🔍 IDOR DETECTION{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    detector = IDORDetector(url, build_config())
    detector.scan(); detector.display_results()
    press_enter()

def rate_limit_module():
    from modules.rate_limit import RateLimitChecker
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[28] ⏱️ RATE LIMIT CHECK{Style.RESET_ALL}")
    url = get_url_input()
    if not url: return
    checker = RateLimitChecker(url, build_config())
    checker.scan(); checker.display_results()
    press_enter()

# ==================== MODULE 29-31: TOOLS ====================

def multi_scanner_module():
    from modules.multi_scanner import MultiTargetScanner
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[29] 🎯 MULTI-TARGET SCANNER{Style.RESET_ALL}")
    print("Enter targets (one per line, empty to finish):")
    targets = []
    while True:
        t = input("  → ").strip()
        if not t: break
        targets.append(t)
    if targets:
        scanner = MultiTargetScanner(targets, {'verbose':get_user_input("Verbose?","y").lower()=='y'})
        scanner.scan(); scanner.display_results()
        print(f"\n{Fore.GREEN}[✓] Saved: {scanner.save_results()}{Style.RESET_ALL}")
    press_enter()

def discord_module():
    from modules.discord_notifier import DiscordNotifier
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[30] 💬 DISCORD WEBHOOK{Style.RESET_ALL}")
    webhook = get_user_input("Discord Webhook URL")
    if webhook:
        notifier = DiscordNotifier(webhook, {'verbose':True})
        print(f"{Fore.GREEN}[✓] Working!{Style.RESET_ALL}" if notifier.test_webhook() else f"{Fore.RED}[✗] Failed!{Style.RESET_ALL}")
    press_enter()

def pro_report_module():
    from modules.pro_report import ProReportGenerator
    from modules.reporter import ReportGenerator
    clear_screen(); print_banner()
    print(f"\n{Fore.GREEN}[31] 📊 PRO REPORT (Charts & Graphs){Style.RESET_ALL}")
    
    scans = ReportGenerator.list_saved_scans()
    if not scans:
        print(f"\n{Fore.YELLOW}[!] No saved scans found!{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}[!] Run Full Audit [8] first to generate scan data.{Style.RESET_ALL}")
        press_enter()
        return
    
    print(f"\n{Fore.CYAN}📂 Available Scan Data:{Style.RESET_ALL}\n")
    for i, s in enumerate(scans, 1):
        print(f"  {Fore.GREEN}[{i}]{Style.RESET_ALL} {s['file']}")
        print(f"      📅 {s['timestamp']} | 🎯 {s['target'][:50]}")
        print(f"      🔗 Endpoints: {s['endpoints']} | ⚠️ Vulns: {s['vulns']} | 🌐 Ports: {s['ports']}\n")
    
    idx = int(get_user_input("Select scan number", "1")) - 1
    if 0 <= idx < len(scans):
        data = ReportGenerator.load_scan_data(scans[idx]['filepath'])
        if data:
            rpt = get_user_input("Report filename", f"pro_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html")
            generator = ProReportGenerator(data)
            filename = generator.generate_html(rpt)
            
            print(f"\n{Fore.GREEN}{'='*50}{Style.RESET_ALL}")
            print(f"{Fore.GREEN}  ✅ PRO REPORT GENERATED!{Style.RESET_ALL}")
            print(f"{Fore.GREEN}{'='*50}{Style.RESET_ALL}")
            print(f"  📄 File: {filename}")
            print(f"  📊 Charts: Severity Distribution + Vulnerability Types")
            print(f"  🔗 Endpoints: {len(data.get('endpoints', []))}")
            print(f"  ⚠️  Vulnerabilities: {len(data.get('vulnerabilities', []))}")
            print(f"  💯 Security Score: Auto-calculated")
            print(f"{Fore.GREEN}{'='*50}{Style.RESET_ALL}")
            print(f"\n{Fore.CYAN}[*] Open this file in browser to view charts!{Style.RESET_ALL}")
        else:
            print(f"\n{Fore.RED}[✗] Failed to load scan data!{Style.RESET_ALL}")
    else:
        print(f"\n{Fore.RED}[✗] Invalid selection!{Style.RESET_ALL}")
    
    press_enter()


# ==================== MAIN MENU ====================

def main():
    while True:
        clear_screen()
        print_banner()
        
        print(f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════╗
║{Fore.YELLOW}  🐛 BUG HUNTER v4.0 - MAIN MENU (31 Modules){Fore.CYAN}      ║
╠══════════════════════════════════════════════════════╣
║                                                      ║
║  {Fore.GREEN}[1]{Fore.CYAN}  🕷️  Web Crawler                                  ║
║  {Fore.GREEN}[2]{Fore.CYAN}  🔍  Vulnerability Scanner                        ║
║  {Fore.GREEN}[3]{Fore.CYAN}  🌐  Port Scanner                                  ║
║  {Fore.GREEN}[4]{Fore.CYAN}  🔬  Technology Detector                          ║
║  {Fore.GREEN}[5]{Fore.CYAN}  🗂️  Sensitive File Finder                        ║
║  {Fore.GREEN}[6]{Fore.CYAN}  📂  Directory Bruteforcer                        ║
║  {Fore.GREEN}[7]{Fore.CYAN}  🛡️  WAF Detector                                 ║
║  {Fore.GREEN}[8]{Fore.CYAN}  🚀  Full Audit (All-in-One + Discord)            ║
║  {Fore.GREEN}[9]{Fore.CYAN}  📊  Report Generator                             ║
║  {Fore.GREEN}[10]{Fore.CYAN} 🔑  Auth Handler (Auto Cookies)                  ║
║                                                      ║
║  {Fore.CYAN}─────────── EXTENDED MODULES ───────────{Fore.CYAN}    ║
║  {Fore.GREEN}[11]{Fore.CYAN} 🌐  Subdomain Finder                             ║
║  {Fore.GREEN}[12]{Fore.CYAN} 🔒  Header Security Analyzer                    ║
║  {Fore.GREEN}[13]{Fore.CYAN} 🔍  JavaScript Secret Finder                    ║
║  {Fore.GREEN}[14]{Fore.CYAN} 📅  Wayback Machine URLs                        ║
║  {Fore.GREEN}[15]{Fore.CYAN} 📧  Email Harvester                             ║
║  {Fore.GREEN}[16]{Fore.CYAN} 🎯  WordPress Scanner                           ║
║  {Fore.GREEN}[17]{Fore.CYAN} 🗺️  Sitemap Parser                              ║
║  {Fore.GREEN}[18]{Fore.CYAN} 🔓  CORS Misconfig Scanner                      ║
║  {Fore.GREEN}[19]{Fore.CYAN} 📸  Screenshot Capture                          ║
║  {Fore.GREEN}[20]{Fore.CYAN} 🔗  Link Checker                                ║
║                                                      ║
║  {Fore.CYAN}─────────── ADVANCED MODULES ───────────{Fore.CYAN}    ║
║  {Fore.GREEN}[21]{Fore.CYAN} 🔒  Security Headers (Enhanced)                 ║
║  {Fore.GREEN}[22]{Fore.CYAN} 📂  Directory Listing Check                     ║
║  {Fore.GREEN}[23]{Fore.CYAN} 🔀  Open Redirect Detector                      ║
║  {Fore.GREEN}[24]{Fore.CYAN} 🌐  Subdomain Takeover Check                    ║
║  {Fore.GREEN}[25]{Fore.CYAN} 🔌  API Endpoint Discovery                      ║
║  {Fore.GREEN}[26]{Fore.CYAN} 🔴  SSRF Payload Checker                        ║
║  {Fore.GREEN}[27]{Fore.CYAN} 🔍  IDOR Endpoint Detection                     ║
║  {Fore.GREEN}[28]{Fore.CYAN} ⏱️  Rate Limit Checker                          ║
║                                                      ║
║  {Fore.CYAN}─────────── TOOLS & UTILITIES ──────────{Fore.CYAN}    ║
║  {Fore.GREEN}[29]{Fore.CYAN} 🎯  Multi-Target Scanner                        ║
║  {Fore.GREEN}[30]{Fore.CYAN} 💬  Discord Webhook Test                        ║
║  {Fore.GREEN}[31]{Fore.CYAN} 📊  Pro Report (Charts & Graphs)                ║
║                                                      ║
║  {Fore.RED}[0]{Fore.CYAN}  🚪  Exit                                         ║
╚════════════════════════════════════════════════════════╝{Style.RESET_ALL}
""")
        
        choice = get_user_input("\nSelect option", "0")
        
        if choice == '1': crawl_module()
        elif choice == '2': scanner_module()
        elif choice == '3': port_scanner_module()
        elif choice == '4': tech_detector_module()
        elif choice == '5': sensitive_files_module()
        elif choice == '6': dir_bruteforce_module()
        elif choice == '7': waf_detector_module()
        elif choice == '8': full_audit_module()
        elif choice == '9': report_menu()
        elif choice == '10': auth_module()
        elif choice == '11': subdomain_module()
        elif choice == '12': header_analyzer_module()
        elif choice == '13': js_analyzer_module()
        elif choice == '14': wayback_module()
        elif choice == '15': email_harvester_module()
        elif choice == '16': wp_scanner_module()
        elif choice == '17': sitemap_module()
        elif choice == '18': cors_scanner_module()
        elif choice == '19': screenshot_module()
        elif choice == '20': link_checker_module()
        elif choice == '21': security_headers_module()
        elif choice == '22': dir_listing_module()
        elif choice == '23': open_redirect_module()
        elif choice == '24': subdomain_takeover_module()
        elif choice == '25': api_finder_module()
        elif choice == '26': ssrf_checker_module()
        elif choice == '27': idor_detector_module()
        elif choice == '28': rate_limit_module()
        elif choice == '29': multi_scanner_module()
        elif choice == '30': discord_module()
        elif choice == '31': pro_report_module()
        elif choice == '0':
            print(f"\n{Fore.GREEN}[✓] Goodbye! Happy Hunting! 🐛{Style.RESET_ALL}\n")
            sys.exit(0)
        else:
            print(f"\n{Fore.RED}[✗] Invalid option!{Style.RESET_ALL}")
            press_enter()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Fore.YELLOW}[!] Exiting...{Style.RESET_ALL}\n")
        sys.exit(0)