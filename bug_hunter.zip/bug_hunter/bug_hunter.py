#!/usr/bin/env python3
"""
Bug Hunter Swiss Knife - Interactive Menu Version
Author: Security Research
Warning: Use only on authorized targets!
"""

import os
import sys
import json
from datetime import datetime
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

def clear_screen():
    """Clear terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_banner():
    """Display main banner"""
    banner = f"""
{Fore.CYAN}╔══════════════════════════════════════════════════════╗
║                                                      ║
║     {Fore.RED}🐛  BUG HUNTER SWISS KNIFE v2.0  🐛{Fore.CYAN}            ║
║     {Fore.YELLOW}    Multi-purpose Bug Bounty Tool{Fore.CYAN}              ║
║     {Fore.GREEN}        Interactive Edition{Fore.CYAN}                   ║
║                                                      ║
╚══════════════════════════════════════════════════════╝{Style.RESET_ALL}
    
{Fore.RED}⚠️  WARNING: Use only on systems you own or have permission to test!{Style.RESET_ALL}
    """
    print(banner)

def print_menu(title, options):
    """Display a menu with options"""
    print(f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}  {title}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n")
    
    for key, value in options.items():
        print(f"  {Fore.GREEN}[{key}]{Style.RESET_ALL} {value}")
    
    print(f"\n  {Fore.GREEN}[0]{Style.RESET_ALL} Back to Main Menu")
    print(f"  {Fore.GREEN}[00]{Style.RESET_ALL} Exit")

def get_user_input(prompt, default=None):
    """Get input from user"""
    try:
        if default:
            user_input = input(f"\n{Fore.YELLOW}[?] {prompt} [{default}]: {Style.RESET_ALL}")
            return user_input.strip() if user_input.strip() else default
        else:
            return input(f"\n{Fore.YELLOW}[?] {prompt}: {Style.RESET_ALL}").strip()
    except KeyboardInterrupt:
        print(f"\n\n{Fore.YELLOW}[!] Operation cancelled by user{Style.RESET_ALL}")
        return None

def get_url_input():
    """Get URL with validation"""
    while True:
        url = get_user_input("Enter target URL")
        if url is None:
            return None
        if url.startswith(('http://', 'https://')):
            return url
        print(f"{Fore.RED}[✗] Invalid URL! Must start with http:// or https://{Style.RESET_ALL}")

def get_ip_input():
    """Get IP/hostname input"""
    return get_user_input("Enter target IP or hostname")

# ==================== MODULE FUNCTIONS ====================

def crawl_module():
    """Web Crawler Module"""
    from modules.crawler import WebCrawler
    
    clear_screen()
    print_banner()
    print(f"\n{Fore.GREEN}[+] WEB CRAWLER MODULE{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'─'*40}{Style.RESET_ALL}")
    
    url = get_url_input()
    if url is None:
        return
    
    depth = get_user_input("Crawl depth (1-10)", "3")
    if depth is None:
        return
    depth = int(depth)
    
    max_urls = get_user_input("Max URLs to crawl", "1000")
    if max_urls is None:
        return
    max_urls = int(max_urls)
    
    verbose = get_user_input("Verbose output? (y/n)", "y").lower() == 'y'
    
    # Advanced options
    print(f"\n{Fore.CYAN}[*] Advanced Options (press Enter to skip){Style.RESET_ALL}")
    cookies = get_user_input("Cookies (name1=value1; name2=value2)")
    delay = get_user_input("Delay between requests (seconds)", "0")
    proxy = get_user_input("Proxy (http://127.0.0.1:8080)")
    user_agent = get_user_input("Custom User-Agent")
    custom_headers = get_user_input("Custom headers (Key:Value, comma separated)")
    
    # Build config
    headers = {}
    if cookies:
        headers['Cookie'] = cookies
    if user_agent:
        headers['User-Agent'] = user_agent
    if custom_headers:
        for header in custom_headers.split(','):
            if ':' in header:
                key, value = header.split(':', 1)
                headers[key.strip()] = value.strip()
    
    config = {
        'headers': headers,
        'delay': float(delay) if delay else 0,
        'proxy': proxy if proxy else None,
        'verbose': verbose
    }
    
    print(f"\n{Fore.CYAN}[*] Starting crawler...{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Target: {url}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Depth: {depth}, Max URLs: {max_urls}{Style.RESET_ALL}\n")
    
    try:
        crawler = WebCrawler(url=url, max_depth=depth, max_urls=max_urls, config=config)
        endpoints = crawler.crawl()
        
        if endpoints:
            print(f"\n{Fore.GREEN}[✓] Found {len(endpoints)} endpoints:{Style.RESET_ALL}\n")
            for i, ep in enumerate(endpoints[:50], 1):
                print(f"  {Fore.CYAN}{i}.{Style.RESET_ALL} {ep}")
            if len(endpoints) > 50:
                print(f"  ... and {len(endpoints) - 50} more")
            
            # Save option
            save = get_user_input("\nSave endpoints to file? (y/n)", "n")
            if save.lower() == 'y':
                filename = get_user_input("Filename", "endpoints.txt")
                with open(filename, 'w') as f:
                    f.write('\n'.join(endpoints))
                print(f"{Fore.GREEN}[✓] Saved to {filename}{Style.RESET_ALL}")
        else:
            print(f"\n{Fore.YELLOW}[!] No endpoints found{Style.RESET_ALL}")
    
    except Exception as e:
        print(f"\n{Fore.RED}[✗] Error: {e}{Style.RESET_ALL}")
    
    input(f"\n{Fore.CYAN}[*] Press Enter to continue...{Style.RESET_ALL}")

def scanner_module():
    """Vulnerability Scanner Module"""
    from modules.scanner import VulnScanner
    
    clear_screen()
    print_banner()
    print(f"\n{Fore.GREEN}[+] VULNERABILITY SCANNER MODULE{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'─'*40}{Style.RESET_ALL}")
    
    url = get_url_input()
    if url is None:
        return
    
    print(f"\n{Fore.CYAN}[*] Select test type:{Style.RESET_ALL}")
    print(f"  [1] XSS only")
    print(f"  [2] SQL Injection only")
    print(f"  [3] Open Redirect only")
    print(f"  [4] All tests")
    
    test_choice = get_user_input("Choice", "4")
    test_map = {'1': 'xss', '2': 'sqli', '3': 'redirect', '4': 'all'}
    test_type = test_map.get(test_choice, 'all')
    
    verbose = get_user_input("Verbose output? (y/n)", "y").lower() == 'y'
    
    # Advanced options
    print(f"\n{Fore.CYAN}[*] Advanced Options (press Enter to skip){Style.RESET_ALL}")
    cookies = get_user_input("Cookies (name1=value1; name2=value2)")
    delay = get_user_input("Delay between requests (seconds)", "0")
    proxy = get_user_input("Proxy (http://127.0.0.1:8080)")
    custom_headers = get_user_input("Custom headers (Key:Value, comma separated)")
    
    # Build config
    headers = {}
    if cookies:
        headers['Cookie'] = cookies
    if custom_headers:
        for header in custom_headers.split(','):
            if ':' in header:
                key, value = header.split(':', 1)
                headers[key.strip()] = value.strip()
    
    config = {
        'headers': headers,
        'delay': float(delay) if delay else 0,
        'proxy': proxy if proxy else None,
        'verbose': verbose
    }
    
    print(f"\n{Fore.CYAN}[*] Starting vulnerability scan...{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Target: {url}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Test: {test_type.upper()}{Style.RESET_ALL}\n")
    
    try:
        scanner = VulnScanner(url=url, test_type=test_type, config=config)
        vulns = scanner.scan()
        
        if vulns:
            print(f"\n{Fore.RED}[!] Vulnerabilities found:{Style.RESET_ALL}\n")
            for vuln in vulns:
                print(f"  {vuln}")
        else:
            print(f"\n{Fore.GREEN}[✓] No vulnerabilities found{Style.RESET_ALL}")
    
    except Exception as e:
        print(f"\n{Fore.RED}[✗] Error: {e}{Style.RESET_ALL}")
    
    input(f"\n{Fore.CYAN}[*] Press Enter to continue...{Style.RESET_ALL}")

def port_scanner_module():
    """Port Scanner Module"""
    from modules.network import NetworkScanner
    
    clear_screen()
    print_banner()
    print(f"\n{Fore.GREEN}[+] PORT SCANNER MODULE{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'─'*40}{Style.RESET_ALL}")
    
    host = get_ip_input()
    if host is None:
        return
    
    print(f"\n{Fore.CYAN}[*] Select port range:{Style.RESET_ALL}")
    print(f"  [1] Quick (1-1000)")
    print(f"  [2] Full (1-10000)")
    print(f"  [3] Common (Top 100)")
    print(f"  [4] Custom")
    
    range_choice = get_user_input("Choice", "1")
    
    if range_choice == '1':
        port_range = "1-1000"
    elif range_choice == '2':
        port_range = "1-10000"
    elif range_choice == '3':
        port_range = "20,21,22,23,25,53,80,110,111,135,139,143,443,445,993,995,1723,3306,3389,5900,8080,8443"
    elif range_choice == '4':
        port_range = get_user_input("Enter range (e.g., 1-1000)")
        if port_range is None:
            return
    else:
        port_range = "1-1000"
    
    threads = get_user_input("Number of threads (1-500)", "100")
    if threads is None:
        return
    threads = int(threads)
    
    verbose = get_user_input("Verbose output? (y/n)", "y").lower() == 'y'
    
    config = {
        'threads': threads,
        'verbose': verbose
    }
    
    # Parse port range
    if '-' in port_range:
        start_port, end_port = map(int, port_range.split('-'))
    elif ',' in port_range:
        ports = [int(p) for p in port_range.split(',')]
        start_port = min(ports)
        end_port = max(ports)
    else:
        start_port, end_port = 1, 1000
    
    print(f"\n{Fore.CYAN}[*] Starting port scan...{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Target: {host}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Ports: {start_port}-{end_port}{Style.RESET_ALL}")
    print(f"{Fore.CYAN}[*] Threads: {threads}{Style.RESET_ALL}\n")
    
    try:
        scanner = NetworkScanner(host=host, port_range=(start_port, end_port), config=config)
        open_ports = scanner.scan()
        
        if open_ports:
            print(f"\n{Fore.GREEN}[✓] Open ports found:{Style.RESET_ALL}\n")
            for port_info in open_ports:
                print(f"  {port_info}")
    
    except Exception as e:
        print(f"\n{Fore.RED}[✗] Error: {e}{Style.RESET_ALL}")
    
    input(f"\n{Fore.CYAN}[*] Press Enter to continue...{Style.RESET_ALL}")

def full_audit_module():
    """Full Audit Module (Crawl + Scan + Report)"""
    from modules.crawler import WebCrawler
    from modules.scanner import VulnScanner
    from modules.reporter import ReportGenerator
    
    clear_screen()
    print_banner()
    print(f"\n{Fore.GREEN}[+] FULL AUDIT MODULE{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'─'*40}{Style.RESET_ALL}")
    print(f"  This will: Crawl → Scan → Generate Report\n")
    
    url = get_url_input()
    if url is None:
        return
    
    depth = get_user_input("Crawl depth (1-10)", "3")
    if depth is None:
        return
    depth = int(depth)
    
    max_urls = get_user_input("Max URLs to crawl", "100")
    if max_urls is None:
        return
    max_urls = int(max_urls)
    
    verbose = get_user_input("Verbose output? (y/n)", "y").lower() == 'y'
    
    # Advanced options
    print(f"\n{Fore.CYAN}[*] Advanced Options (press Enter to skip){Style.RESET_ALL}")
    cookies = get_user_input("Cookies (name1=value1; name2=value2)")
    delay = get_user_input("Delay between requests (seconds)", "0.5")
    proxy = get_user_input("Proxy (http://127.0.0.1:8080)")
    
    report_name = get_user_input("Report filename", f"audit_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html")
    
    # Build config
    headers = {}
    if cookies:
        headers['Cookie'] = cookies
    
    config = {
        'headers': headers,
        'delay': float(delay) if delay else 0,
        'proxy': proxy if proxy else None,
        'verbose': verbose
    }
    
    results = {
        'scan_info': {
            'timestamp': datetime.now().isoformat(),
            'command': f'Full audit of {url}',
        },
        'endpoints': [],
        'vulnerabilities': [],
        'open_ports': []
    }
    
    print(f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}  PHASE 1/3: Crawling{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n")
    
    try:
        # Phase 1: Crawl
        crawler = WebCrawler(url=url, max_depth=depth, max_urls=max_urls, config=config)
        endpoints = crawler.crawl()
        results['endpoints'] = endpoints
        print(f"\n{Fore.GREEN}[✓] Found {len(endpoints)} endpoints{Style.RESET_ALL}")
        
        # Phase 2: Scan
        print(f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  PHASE 2/3: Scanning{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n")
        
        all_vulns = []
        # Scan main URL
        print(f"{Fore.CYAN}[*] Scanning main URL...{Style.RESET_ALL}")
        scanner = VulnScanner(url=url, test_type='all', config=config)
        vulns = scanner.scan()
        if vulns:
            all_vulns.extend([f"[Main URL] {v}" for v in vulns if 'No vulnerabilities' not in v])
        
        # Scan endpoints with parameters
        param_endpoints = [ep for ep in endpoints if '?' in ep][:20]
        if param_endpoints:
            print(f"{Fore.CYAN}[*] Scanning {len(param_endpoints)} endpoints with parameters...{Style.RESET_ALL}")
            for i, endpoint in enumerate(param_endpoints, 1):
                if verbose:
                    print(f"  [{i}/{len(param_endpoints)}] {endpoint}")
                scanner = VulnScanner(url=endpoint, test_type='all', config=config)
                vulns = scanner.scan()
                if vulns:
                    all_vulns.extend([f"[{endpoint}] {v}" for v in vulns if 'No vulnerabilities' not in v])
        
        results['vulnerabilities'] = all_vulns
        vuln_count = len([v for v in all_vulns if 'No vulnerabilities' not in v])
        print(f"\n{Fore.RED if vuln_count > 0 else Fore.GREEN}[!] Found {vuln_count} potential vulnerabilities{Style.RESET_ALL}")
        
        # Phase 3: Generate Report
        print(f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  PHASE 3/3: Generating Report{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n")
        
        reporter = ReportGenerator(results)
        reporter.generate_html(report_name)
        print(f"{Fore.GREEN}[✓] Report generated: {report_name}{Style.RESET_ALL}")
        
        # Summary
        print(f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  AUDIT COMPLETE{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
        print(f"  Endpoints:     {len(endpoints)}")
        print(f"  Vulnerabilities: {vuln_count}")
        print(f"  Report:        {report_name}")
        print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
    
    except Exception as e:
        print(f"\n{Fore.RED}[✗] Error: {e}{Style.RESET_ALL}")
        import traceback
        if verbose:
            traceback.print_exc()
    
    input(f"\n{Fore.CYAN}[*] Press Enter to continue...{Style.RESET_ALL}")

def generate_report_menu():
    """Generate Report from previous scan"""
    clear_screen()
    print_banner()
    print(f"\n{Fore.GREEN}[+] REPORT GENERATOR{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'─'*40}{Style.RESET_ALL}")
    
    print(f"\n{Fore.YELLOW}[!] This module generates a demo report.{Style.RESET_ALL}")
    print(f"{Fore.YELLOW}[!] For actual reports, use Full Audit module.{Style.RESET_ALL}\n")
    
    filename = get_user_input("Report filename", "report.html")
    if filename is None:
        return
    
    # Create demo report
    from modules.reporter import ReportGenerator
    
    demo_results = {
        'scan_info': {
            'timestamp': datetime.now().isoformat(),
            'command': 'Demo Report',
        },
        'endpoints': [
            'https://example.com/login',
            'https://example.com/api/users',
            'https://example.com/admin',
            'https://example.com/search?q=test',
        ],
        'vulnerabilities': [
            '[XSS] Parameter: q | Payload: <script>alert(1)</script>',
            '[SQLi] Parameter: id | Error: SQL syntax',
        ],
        'open_ports': [
            '[+] Port 80: HTTP',
            '[+] Port 443: HTTPS',
            '[+] Port 22: SSH',
        ]
    }
    
    reporter = ReportGenerator(demo_results)
    reporter.generate_html(filename)
    print(f"\n{Fore.GREEN}[✓] Demo report generated: {filename}{Style.RESET_ALL}")
    
    input(f"\n{Fore.CYAN}[*] Press Enter to continue...{Style.RESET_ALL}")

def settings_menu():
    """Settings & Configuration"""
    clear_screen()
    print_banner()
    print(f"\n{Fore.GREEN}[+] SETTINGS{Style.RESET_ALL}")
    print(f"{Fore.CYAN}{'─'*40}{Style.RESET_ALL}")
    
    print(f"\n{Fore.CYAN}Current Configuration:{Style.RESET_ALL}")
    print(f"  Default Threads: 100")
    print(f"  Default Delay: 0.5s")
    print(f"  Default Depth: 3")
    print(f"  Default Max URLs: 1000")
    print(f"  User-Agent: BugHunter/2.0")
    
    print(f"\n{Fore.YELLOW}[!] Settings will be saved in future versions.{Style.RESET_ALL}")
    
    input(f"\n{Fore.CYAN}[*] Press Enter to continue...{Style.RESET_ALL}")

# ==================== MAIN MENU ====================

def main():
    """Main menu loop"""
    while True:
        clear_screen()
        print_banner()
        
        print(f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  MAIN MENU{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}\n")
        
        print(f"  {Fore.GREEN}[1]{Style.RESET_ALL}  🕷️  Web Crawler - Find endpoints & links")
        print(f"  {Fore.GREEN}[2]{Style.RESET_ALL}  🔍  Vulnerability Scanner - Test XSS, SQLi, Redirect")
        print(f"  {Fore.GREEN}[3]{Style.RESET_ALL}  🌐  Port Scanner - Discover open ports")
        print(f"  {Fore.GREEN}[4]{Style.RESET_ALL}  🚀  Full Audit - Crawl + Scan + Report")
        print(f"  {Fore.GREEN}[5]{Style.RESET_ALL}  📊  Generate Report - Create HTML report")
        print(f"  {Fore.GREEN}[6]{Style.RESET_ALL}  ⚙️  Settings - Configure tool")
        print(f"\n  {Fore.GREEN}[0]{Style.RESET_ALL}  🚪  Exit")
        
        choice = get_user_input("\nSelect option", "0")
        
        if choice == '1':
            crawl_module()
        elif choice == '2':
            scanner_module()
        elif choice == '3':
            port_scanner_module()
        elif choice == '4':
            full_audit_module()
        elif choice == '5':
            generate_report_menu()
        elif choice == '6':
            settings_menu()
        elif choice == '0':
            print(f"\n{Fore.GREEN}[✓] Goodbye! Happy Hunting! 🐛{Style.RESET_ALL}\n")
            sys.exit(0)
        else:
            print(f"\n{Fore.RED}[✗] Invalid option!{Style.RESET_ALL}")
            input(f"\n{Fore.CYAN}[*] Press Enter to continue...{Style.RESET_ALL}")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Fore.YELLOW}[!] Exiting...{Style.RESET_ALL}\n")
        sys.exit(0)