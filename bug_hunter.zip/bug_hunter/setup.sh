#!/bin/bash
# Bug Hunter Swiss Knife - Auto Installer
# One command setup for Termux

clear

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║     🐛 BUG HUNTER SWISS KNIFE - INSTALLER 🐛       ║"
echo "║              Auto Setup Script                      ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Check if Termux
if [ -d "/data/data/com.termux" ]; then
    echo "[*] Termux detected!"
    pkg update -y
    pkg install python -y
    pkg install curl -y
    pkg install git -y
    pkg install wget -y
fi

# Create project structure
echo "[*] Creating project structure..."
mkdir -p bug_hunter/modules
mkdir -p bug_hunter/wordlists
mkdir -p bug_hunter/reports

# Copy all files
echo "[*] Copying files..."
cp bug_hunter_menu.py bug_hunter/ 2>/dev/null
cp bug_hunter.py bug_hunter/ 2>/dev/null
cp requirements.txt bug_hunter/ 2>/dev/null
cp -r modules/* bug_hunter/modules/ 2>/dev/null
cp -r wordlists/* bug_hunter/wordlists/ 2>/dev/null

cd bug_hunter

# Install Python packages
echo "[*] Installing Python packages..."
pip install -r requirements.txt

# Make scripts executable
chmod +x bug_hunter_menu.py
chmod +x bug_hunter.py

# Create alias
echo ""
echo "[*] Creating alias..."
SHELL_RC="$HOME/.bashrc"
if [ -f "$HOME/.zshrc" ]; then
    SHELL_RC="$HOME/.zshrc"
fi

echo "alias bh='cd $(pwd) && python bug_hunter_menu.py'" >> $SHELL_RC
echo "alias bug-hunter='cd $(pwd) && python bug_hunter_menu.py'" >> $SHELL_RC

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║     ✅ INSTALLATION COMPLETE!                       ║"
echo "║                                                      ║"
echo "║     Run: bh                                          ║"
echo "║     Or:  bug-hunter                                  ║"
echo "║     Or:  cd bug_hunter && python bug_hunter_menu.py ║"
echo "╚══════════════════════════════════════════════════════╝"
echo ""

# Reload shell
source $SHELL_RC 2>/dev/null
