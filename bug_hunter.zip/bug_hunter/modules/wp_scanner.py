import requests
import re
import json
from urllib.parse import urljoin
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WPScanner:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.is_wordpress = False
        self.wp_version = None
        self.theme = None
        self.plugins = []
        self.users = []
        self.vulnerable = []
    
    def detect_wordpress(self):
        """Detect if site is WordPress"""
        checks = [
            '/wp-login.php',
            '/wp-admin/',
            '/wp-content/',
            '/wp-includes/',
            '/xmlrpc.php',
        ]
        
        for check in checks:
            try:
                url = urljoin(self.url, check)
                response = self.session.get(url, timeout=10)
                if response.status_code in [200, 301, 302, 403]:
                    self.is_wordpress = True
                    if self.verbose:
                        print(f"  [✓] WordPress detected: {check}")
                    return True
            except:
                pass
        
        return False
    
    def get_version(self):
        """Get WordPress version"""
        try:
            # Check readme.html
            response = self.session.get(urljoin(self.url, '/readme.html'), timeout=10)
            match = re.search(r'Version (\d+\.\d+(?:\.\d+)?)', response.text)
            if match:
                self.wp_version = match.group(1)
                return self.wp_version
            
            # Check meta tag
            response = self.session.get(self.url, timeout=10)
            match = re.search(r'<meta name="generator" content="WordPress (\d+\.\d+(?:\.\d+)?)"', response.text)
            if match:
                self.wp_version = match.group(1)
                return self.wp_version
            
            # Check feed
            response = self.session.get(urljoin(self.url, '/feed/'), timeout=10)
            match = re.search(r'<generator>https://wordpress.org/\?v=(\d+\.\d+(?:\.\d+)?)</generator>', response.text)
            if match:
                self.wp_version = match.group(1)
                return self.wp_version
                
        except:
            pass
        return None
    
    def enumerate_users(self):
        """Enumerate WordPress users"""
        try:
            # REST API method
            response = self.session.get(urljoin(self.url, '/wp-json/wp/v2/users'), timeout=10)
            if response.status_code == 200:
                users = response.json()
                for user in users:
                    self.users.append({
                        'id': user.get('id'),
                        'name': user.get('name'),
                        'slug': user.get('slug')
                    })
                return self.users
            
            # Author enumeration
            for i in range(1, 11):
                try:
                    response = self.session.get(f"{self.url}/?author={i}", timeout=10, allow_redirects=False)
                    if response.status_code == 301:
                        location = response.headers.get('Location', '')
                        username = location.rstrip('/').split('/')[-1]
                        self.users.append({'id': i, 'name': username, 'slug': username})
                except:
                    pass
                    
        except:
            pass
        return self.users
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Scanning WordPress: {self.url}")
        
        if not self.detect_wordpress():
            if self.verbose:
                print(f"  [!] Not a WordPress site")
            return False
        
        # Get version
        self.get_version()
        if self.wp_version and self.verbose:
            print(f"  [✓] Version: {self.wp_version}")
        
        # Enumerate users
        self.enumerate_users()
        if self.users and self.verbose:
            print(f"  [✓] Users found: {len(self.users)}")
        
        return True
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🎯 WORDPRESS SCANNER RESULTS")
        print(f"{'='*50}")
        
        if not self.is_wordpress:
            print(f"\n  ❌ Not a WordPress site")
        else:
            print(f"\n  ✅ WordPress Detected!")
            
            if self.wp_version:
                print(f"\n  📌 Version: {self.wp_version}")
            
            if self.users:
                print(f"\n  👤 Users ({len(self.users)}):")
                for user in self.users:
                    print(f"    • ID: {user.get('id')} | Name: {user.get('name')} | Slug: {user.get('slug')}")
            
            print(f"\n  🔗 Useful URLs:")
            print(f"    • Admin: {self.url}/wp-admin/")
            print(f"    • Login: {self.url}/wp-login.php")
            print(f"    • XMLRPC: {self.url}/xmlrpc.php")
            print(f"    • REST API: {self.url}/wp-json/wp/v2/")
        
        print(f"{'='*50}")
