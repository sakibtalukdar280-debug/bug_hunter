#!/usr/bin/env python3
"""
Professional Report Generator with Charts
Bug Hunter Swiss Knife v4.0
"""

import json
from datetime import datetime
from collections import Counter

class ProReportGenerator:
    def __init__(self, results):
        self.results = results
    
    def generate_html(self, filename=None):
        if not filename:
            filename = f"pro_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        
        endpoints = self.results.get('endpoints', [])
        vulnerabilities = self.results.get('vulnerabilities', [])
        technologies = self.results.get('technologies', {})
        sensitive_files = self.results.get('sensitive_files', [])
        directories = self.results.get('directories', [])
        open_ports = self.results.get('open_ports', [])
        waf = self.results.get('waf', None)
        scan_info = self.results.get('scan_info', {})
        
        # Calculate stats
        real_vulns = [v for v in vulnerabilities if 'No vulnerabilities' not in v and v]
        
        # Count vulnerability types
        vuln_types = Counter()
        for v in real_vulns:
            v_upper = v.upper()
            if 'XSS' in v_upper: vuln_types['XSS'] += 1
            elif 'SQL' in v_upper and 'INJECT' in v_upper: vuln_types['SQL Injection'] += 1
            elif 'SQLI' in v_upper: vuln_types['SQL Injection'] += 1
            elif 'REDIRECT' in v_upper: vuln_types['Open Redirect'] += 1
            elif 'IDOR' in v_upper: vuln_types['IDOR'] += 1
            elif 'SSRF' in v_upper: vuln_types['SSRF'] += 1
            elif 'CRITICAL' in v_upper or 'RCE' in v_upper: vuln_types['Critical'] += 1
            else: vuln_types['Other'] += 1
        
        # Count technologies
        total_tech = sum(len(v) for v in technologies.values()) if technologies else 0
        
        # Severity distribution
        severity_dist = {'Critical': 0, 'High': 0, 'Medium': 0, 'Low': 0, 'Info': 0}
        for v in real_vulns:
            v_upper = v.upper()
            if 'CRITICAL' in v_upper or 'RCE' in v_upper or 'SHELL' in v_upper:
                severity_dist['Critical'] += 1
            elif 'HIGH' in v_upper or 'SQL' in v_upper:
                severity_dist['High'] += 1
            elif 'MEDIUM' in v_upper or 'XSS' in v_upper or 'REDIRECT' in v_upper:
                severity_dist['Medium'] += 1
            elif 'LOW' in v_upper or 'INFO' in v_upper:
                severity_dist['Low'] += 1
            else:
                severity_dist['Info'] += 1
        
        # Security score
        base_score = 100
        score_deduction = len(real_vulns) * 5
        if waf: score_deduction -= 10  # WAF is good
        security_score = max(10, base_score - score_deduction)
        
        # Grade
        if security_score >= 90: grade = 'A'
        elif security_score >= 75: grade = 'B'
        elif security_score >= 60: grade = 'C'
        elif security_score >= 40: grade = 'D'
        else: grade = 'F'
        
        grade_colors = {'A': '#00c851', 'B': '#7cb342', 'C': '#ffbb33', 'D': '#ff8800', 'F': '#ff4444'}
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bug Hunter Pro Report | {scan_info.get('command', 'Security Scan')[:50]}</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: #0a0e17;
            color: #e0e0e0;
            line-height: 1.6;
        }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 20px; }}
        
        /* Header */
        .header {{
            background: linear-gradient(135deg, #0f1729 0%, #1a1f35 100%);
            border: 1px solid #2a3050;
            border-radius: 20px;
            padding: 40px;
            margin-bottom: 30px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }}
        .header::before {{
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(0,210,255,0.05) 0%, transparent 70%);
            animation: rotate 20s linear infinite;
        }}
        @keyframes rotate {{ 100% {{ transform: rotate(360deg); }} }}
        .header h1 {{
            font-size: 3em;
            background: linear-gradient(135deg, #00d2ff, #7b2ff7);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            position: relative;
        }}
        .header .subtitle {{ color: #6b7db3; font-size: 1.2em; margin-top: 10px; position: relative; }}
        .header .meta {{ color: #4a5568; margin-top: 15px; font-size: 0.9em; position: relative; }}
        
        /* Score Circle */
        .score-section {{ text-align: center; margin: 30px 0; }}
        .score-circle {{
            width: 160px;
            height: 160px;
            border-radius: 50%;
            background: conic-gradient({grade_colors.get(grade, '#ff4444')} 0% {security_score}%, #1a1f35 {security_score}% 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
            position: relative;
            box-shadow: 0 0 40px rgba(0,210,255,0.1);
        }}
        .score-inner {{
            width: 130px;
            height: 130px;
            border-radius: 50%;
            background: #0a0e17;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }}
        .score-number {{ font-size: 2.5em; font-weight: bold; color: {grade_colors.get(grade, '#ff4444')}; }}
        .score-grade {{ font-size: 1.2em; color: {grade_colors.get(grade, '#ff4444')}; font-weight: bold; }}
        
        /* Stats Grid */
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: #111827;
            border: 1px solid #2a3050;
            border-radius: 16px;
            padding: 25px;
            text-align: center;
            transition: all 0.3s;
            cursor: default;
        }}
        .stat-card:hover {{
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(0,210,255,0.1);
            border-color: #00d2ff;
        }}
        .stat-card .icon {{ font-size: 2em; margin-bottom: 10px; }}
        .stat-card .number {{ font-size: 2.5em; font-weight: bold; margin: 5px 0; }}
        .stat-card .label {{ color: #6b7db3; font-size: 0.9em; }}
        
        /* Sections */
        .section {{
            background: #111827;
            border: 1px solid #2a3050;
            border-radius: 16px;
            padding: 30px;
            margin-bottom: 25px;
        }}
        .section h2 {{
            color: #00d2ff;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #2a3050;
            font-size: 1.5em;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        /* Charts Row */
        .charts-row {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }}
        @media (max-width: 768px) {{
            .charts-row {{ grid-template-columns: 1fr; }}
        }}
        .chart-box {{
            background: #0d1117;
            border-radius: 12px;
            padding: 20px;
        }}
        .chart-box h3 {{
            color: #6b7db3;
            text-align: center;
            margin-bottom: 15px;
            font-size: 1em;
        }}
        
        /* Vulnerability Cards */
        .vuln-card {{
            background: #0d1117;
            border-left: 4px solid;
            padding: 15px;
            margin: 10px 0;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 0.9em;
        }}
        .vuln-critical {{ border-left-color: #ff4444; }}
        .vuln-high {{ border-left-color: #ff8800; }}
        .vuln-medium {{ border-left-color: #ffbb33; }}
        .vuln-low {{ border-left-color: #00c851; }}
        .vuln-info {{ border-left-color: #00d2ff; }}
        
        /* Endpoint List */
        .endpoint-item {{
            background: #0d1117;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        .method-badge {{
            display: inline-block;
            padding: 3px 10px;
            border-radius: 4px;
            font-size: 0.7em;
            font-weight: bold;
            text-transform: uppercase;
            min-width: 45px;
            text-align: center;
        }}
        .method-GET {{ background: #1e40af; color: #93c5fd; }}
        .method-POST {{ background: #166534; color: #86efac; }}
        
        /* Tech Tags */
        .tech-tag {{
            display: inline-block;
            padding: 6px 15px;
            margin: 4px;
            background: #1a1f35;
            color: #00d2ff;
            border-radius: 20px;
            font-size: 0.85em;
            border: 1px solid #2a3050;
        }}
        
        /* WAF Badge */
        .waf-badge {{
            padding: 10px 25px;
            border-radius: 25px;
            font-weight: bold;
            display: inline-block;
            font-size: 1.1em;
        }}
        .waf-found {{ background: #ff444420; color: #ff4444; border: 1px solid #ff4444; }}
        .waf-not-found {{ background: #00c85120; color: #00c851; border: 1px solid #00c851; }}
        
        /* Port Grid */
        .port-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 10px;
        }}
        .port-item {{
            background: #0d1117;
            padding: 12px;
            border-radius: 8px;
            text-align: center;
            font-family: 'Courier New', monospace;
            border: 1px solid #2a3050;
        }}
        
        /* File Items */
        .file-item {{
            background: #0d1117;
            padding: 12px 15px;
            margin: 5px 0;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 0.85em;
        }}
        .file-danger {{ border-left: 3px solid #ff4444; }}
        .file-warning {{ border-left: 3px solid #ffbb33; }}
        
        /* Footer */
        .footer {{
            text-align: center;
            padding: 30px;
            color: #6b7db3;
            border-top: 1px solid #2a3050;
            margin-top: 40px;
        }}
        
        /* Summary Grid */
        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            text-align: center;
        }}
        
        /* Empty State */
        .empty-state {{
            text-align: center;
            padding: 40px;
            color: #4a5568;
        }}
        .empty-state .icon {{ font-size: 3em; margin-bottom: 10px; }}
        
        /* Pulse Animation */
        .pulse {{ animation: pulse 2s infinite; }}
        @keyframes pulse {{ 0%, 100% {{ opacity: 1; }} 50% {{ opacity: 0.6; }} }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <h1>🐛 Bug Hunter Pro Report</h1>
            <div class="subtitle">Professional Security Assessment</div>
            <div class="meta">
                📅 {scan_info.get('timestamp', datetime.now().isoformat())} | 
                🎯 {scan_info.get('command', 'N/A')[:60]} | 
                🛠️ Bug Hunter v4.0
            </div>
        </div>
        
        <!-- Score Section -->
        <div class="score-section">
            <div class="score-circle">
                <div class="score-inner">
                    <div class="score-number">{security_score}</div>
                    <div class="score-grade">Grade {grade}</div>
                </div>
            </div>
            <p style="color: #6b7db3; margin-top: 10px;">Security Score</p>
        </div>
        
        <!-- Stats Grid -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="icon">🔗</div>
                <div class="number" style="color: #00d2ff;">{len(endpoints)}</div>
                <div class="label">Endpoints</div>
            </div>
            <div class="stat-card">
                <div class="icon">⚠️</div>
                <div class="number" style="color: #ff4444;">{len(real_vulns)}</div>
                <div class="label">Vulnerabilities</div>
            </div>
            <div class="stat-card">
                <div class="icon">🔧</div>
                <div class="number" style="color: #7b2ff7;">{total_tech}</div>
                <div class="label">Technologies</div>
            </div>
            <div class="stat-card">
                <div class="icon">🛡️</div>
                <div class="number" style="color: #ff8800;">{1 if waf else 0}</div>
                <div class="label">WAF {'Detected' if waf else 'Not Found'}</div>
            </div>
            <div class="stat-card">
                <div class="icon">🗂️</div>
                <div class="number" style="color: #ffbb33;">{len(sensitive_files) if sensitive_files else 0}</div>
                <div class="label">Sensitive Files</div>
            </div>
            <div class="stat-card">
                <div class="icon">📂</div>
                <div class="number" style="color: #00c851;">{len(directories) if directories else 0}</div>
                <div class="label">Directories</div>
            </div>
        </div>
        
        <!-- WAF Status -->
        <div class="section" style="text-align: center;">
            <h2 style="justify-content: center;">🛡️ WAF Detection</h2>
            <span class="waf-badge {'waf-found' if waf else 'waf-not-found'}">
                {'⚠️ WAF Detected: ' + waf if waf else '✅ No WAF Detected'}
            </span>
        </div>
        
        <!-- Charts -->
        <div class="charts-row">
            <div class="section">
                <h2>📊 Severity Distribution</h2>
                <div class="chart-box">
                    <canvas id="severityChart"></canvas>
                </div>
            </div>
            <div class="section">
                <h2>🎯 Vulnerability Types</h2>
                <div class="chart-box">
                    <canvas id="vulnTypeChart"></canvas>
                </div>
            </div>
        </div>
"""
        
        # Vulnerabilities Section
        html += """
        <div class="section">
            <h2>🔴 Vulnerabilities Found</h2>
"""
        if real_vulns:
            for v in real_vulns:
                v_upper = v.upper()
                if 'CRITICAL' in v_upper or 'RCE' in v_upper: severity = 'critical'
                elif 'HIGH' in v_upper or 'SQL' in v_upper: severity = 'high'
                elif 'MEDIUM' in v_upper or 'XSS' in v_upper: severity = 'medium'
                elif 'LOW' in v_upper: severity = 'low'
                else: severity = 'info'
                
                html += f'<div class="vuln-card vuln-{severity}">{v}</div>'
        else:
            html += '<div class="empty-state"><div class="icon">✅</div><p>No vulnerabilities detected</p></div>'
        html += '</div>'
        
        # Sensitive Files Section
        if sensitive_files:
            html += '<div class="section"><h2>🗂️ Sensitive Files</h2>'
            accessible = [f for f in sensitive_files if f.get('status') == 200] if isinstance(sensitive_files[0], dict) else []
            restricted = [f for f in sensitive_files if f.get('status') in [301, 302, 403]] if isinstance(sensitive_files[0], dict) else []
            
            if accessible:
                html += f'<p style="color: #ff4444; margin-bottom: 10px;">🔴 Accessible ({len(accessible)}):</p>'
                for f in accessible:
                    html += f'<div class="file-item file-danger">📄 {f.get("url", f)}</div>'
            if restricted:
                html += f'<p style="color: #ffbb33; margin-bottom: 10px;">🟡 Restricted ({len(restricted)}):</p>'
                for f in restricted:
                    html += f'<div class="file-item file-warning">🔒 {f.get("url", f)} (Status: {f.get("status")})</div>'
            html += '</div>'
        
        # Directories Section
        if directories:
            html += '<div class="section"><h2>📂 Discovered Directories</h2>'
            for d in directories[:30]:
                html += f'<div class="file-item">📁 {d.get("url", d)} (Status: {d.get("status", "N/A")})</div>'
            html += '</div>'
        
        # Technologies Section
        if technologies:
            html += '<div class="section"><h2>🔧 Technologies Detected</h2>'
            for category, techs in technologies.items():
                if techs:
                    html += f'<h3 style="color: #6b7db3; margin: 15px 0 5px 0;">{category}:</h3>'
                    for tech in techs:
                        html += f'<span class="tech-tag">{tech}</span>'
            html += '</div>'
        
        # Endpoints Section
        if endpoints:
            html += '<div class="section"><h2>🔗 Discovered Endpoints</h2>'
            for ep in endpoints[:50]:
                method = 'POST' if any(x in ep.lower() for x in ['login', 'signup', 'register', 'submit', 'upload']) else 'GET'
                html += f'<div class="endpoint-item"><span class="method-badge method-{method}">{method}</span>{ep[:100]}</div>'
            if len(endpoints) > 50:
                html += f'<p style="color: #6b7db3; margin-top: 10px;">... and {len(endpoints) - 50} more endpoints</p>'
            html += '</div>'
        
        # Open Ports Section
        if open_ports:
            html += '<div class="section"><h2>🌐 Open Ports</h2><div class="port-grid">'
            for port in open_ports:
                if '[+]' in str(port) or 'Port' in str(port):
                    html += f'<div class="port-item">🔌 {port}</div>'
            html += '</div></div>'
        
        # Charts JavaScript
        html += f"""
        
        <!-- Charts -->
        <script>
        // Severity Doughnut Chart
        const severityCtx = document.getElementById('severityChart').getContext('2d');
        new Chart(severityCtx, {{
            type: 'doughnut',
            data: {{
                labels: ['Critical', 'High', 'Medium', 'Low', 'Info'],
                datasets: [{{
                    data: [{severity_dist['Critical']}, {severity_dist['High']}, {severity_dist['Medium']}, {severity_dist['Low']}, {severity_dist['Info']}],
                    backgroundColor: ['#ff4444', '#ff8800', '#ffbb33', '#00c851', '#00d2ff'],
                    borderColor: '#0a0e17',
                    borderWidth: 3,
                    hoverBorderColor: '#2a3050'
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: true,
                plugins: {{
                    legend: {{
                        position: 'bottom',
                        labels: {{ color: '#e0e0e0', padding: 15, font: {{ size: 12 }} }}
                    }}
                }},
                cutout: '60%'
            }}
        }});
        
        // Vulnerability Type Bar Chart
        const vulnTypeCtx = document.getElementById('vulnTypeChart').getContext('2d');
        new Chart(vulnTypeCtx, {{
            type: 'bar',
            data: {{
                labels: ['XSS', 'SQLi', 'Redirect', 'IDOR', 'SSRF', 'Critical', 'Other'],
                datasets: [{{
                    label: 'Count',
                    data: [
                        {vuln_types.get('XSS', 0)}, 
                        {vuln_types.get('SQL Injection', 0)}, 
                        {vuln_types.get('Open Redirect', 0)}, 
                        {vuln_types.get('IDOR', 0)}, 
                        {vuln_types.get('SSRF', 0)}, 
                        {vuln_types.get('Critical', 0)}, 
                        {vuln_types.get('Other', 0)}
                    ],
                    backgroundColor: [
                        '#00d2ff', '#ff4444', '#ff8800', '#7b2ff7', '#ffbb33', '#ff4444', '#6b7db3'
                    ],
                    borderRadius: 8,
                    borderSkipped: false
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: true,
                plugins: {{
                    legend: {{ display: false }}
                }},
                scales: {{
                    y: {{
                        beginAtZero: true,
                        ticks: {{ color: '#e0e0e0', stepSize: 1 }},
                        grid: {{ color: '#2a3050' }}
                    }},
                    x: {{
                        ticks: {{ color: '#e0e0e0' }},
                        grid: {{ display: false }}
                    }}
                }}
            }}
        }});
        </script>
        
        <!-- Summary -->
        <div class="section">
            <h2>📋 Scan Summary</h2>
            <div class="summary-grid">
                <div>
                    <div style="font-size: 2em; color: #00d2ff;">{len(endpoints)}</div>
                    <div style="color: #6b7db3;">Endpoints</div>
                </div>
                <div>
                    <div style="font-size: 2em; color: #ff4444;">{len(real_vulns)}</div>
                    <div style="color: #6b7db3;">Vulnerabilities</div>
                </div>
                <div>
                    <div style="font-size: 2em; color: #00c851;">{security_score}%</div>
                    <div style="color: #6b7db3;">Security Score</div>
                </div>
            </div>
        </div>
        
        <!-- Footer -->
        <div class="footer">
            <p>🐛 <strong>Bug Hunter Swiss Knife v4.0</strong> | Professional Edition</p>
            <p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p style="margin-top: 10px;">⚠️ Automated security assessment - Manual verification recommended</p>
            <p style="color: #4a5568; font-size: 0.8em; margin-top: 5px;">Charts powered by Chart.js</p>
        </div>
    </div>
</body>
</html>
"""
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html)
        
        return filename