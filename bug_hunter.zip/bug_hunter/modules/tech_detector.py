import requests
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class TechDetector:
    def __init__(self, url, config=None):
        self.url = url
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        if 'User-Agent' not in self.session.headers:
            self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.tech_signatures = {
            'Programming Languages': {
                'PHP': ['php', 'PHPSESSID', '.php'],
                'Python': ['python', 'django', 'flask', 'werkzeug'],
                'Ruby': ['ruby', 'rails', 'rack'],
                'Node.js': ['node', 'express', 'socket.io'],
                'Java': ['jsp', 'servlet', 'spring', 'struts'],
                'ASP.NET': ['asp.net', '__viewstate', '.aspx'],
                'Go': ['golang', 'go/'],
            },
            'Web Servers': {
                'Apache': ['apache', 'httpd'],
                'Nginx': ['nginx'],
                'IIS': ['iis', 'microsoft-iis'],
                'LiteSpeed': ['litespeed'],
                'Tomcat': ['tomcat'],
            },
            'JavaScript Frameworks': {
                'React': ['react', '__REACT_DEVTOOLS_GLOBAL_HOOK__'],
                'Vue.js': ['vue', 'v-bind', 'v-if'],
                'Angular': ['angular', 'ng-version'],
                'jQuery': ['jquery'],
                'Bootstrap': ['bootstrap'],
            },
            'CMS': {
                'WordPress': ['wordpress', 'wp-content', 'wp-json'],
                'Joomla': ['joomla', 'com_content'],
                'Drupal': ['drupal', 'sites/all'],
                'Magento': ['magento', 'mage'],
                'Shopify': ['shopify', 'myshopify'],
            },
            'Hosting/CDN': {
                'Cloudflare': ['cloudflare'],
                'AWS': ['aws', 'amazonaws', 'cloudfront'],
                'Netlify': ['netlify'],
                'Vercel': ['vercel', 'now.sh'],
                'Heroku': ['heroku'],
            },
        }
        
        self.detected_tech = {}
    
    def detect(self):
        if self.verbose:
            print(f"\n[*] Detecting technologies on: {self.url}")
        
        try:
            response = self.session.get(self.url, timeout=10)
            headers = response.headers
            body = response.text.lower()
            
            server = headers.get('Server', '')
            powered_by = headers.get('X-Powered-By', '')
            set_cookie = headers.get('Set-Cookie', '')
            
            all_text = f"{server} {powered_by} {set_cookie} {body}"
            
            for category, technologies in self.tech_signatures.items():
                self.detected_tech[category] = []
                for tech, signatures in technologies.items():
                    for sig in signatures:
                        if sig.lower() in all_text:
                            if tech not in self.detected_tech[category]:
                                self.detected_tech[category].append(tech)
                                if self.verbose:
                                    print(f"  [✓] {category}: {tech}")
                            break
            
            return self.detected_tech
            
        except Exception as e:
            if self.verbose:
                print(f"[✗] Error: {e}")
            return {}
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🔍 TECHNOLOGY DETECTION RESULTS")
        print(f"{'='*50}")
        
        total_tech = 0
        for category, technologies in self.detected_tech.items():
            if technologies:
                total_tech += len(technologies)
                print(f"\n  {category}:")
                for tech in technologies:
                    print(f"    • {tech}")
        
        if total_tech == 0:
            print(f"\n  No technologies detected")
        else:
            print(f"\n  Total: {total_tech} technologies detected")
        
        print(f"{'='*50}")
