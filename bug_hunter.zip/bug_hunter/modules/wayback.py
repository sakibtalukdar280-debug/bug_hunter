import requests
import json
from urllib.parse import urlparse
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WaybackMachine:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.domain = urlparse(self.url).netloc
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.wayback_urls = []
        self.unique_endpoints = set()
        self.interesting_files = []
    
    def fetch_wayback_urls(self):
        """Fetch URLs from Wayback Machine"""
        if self.verbose:
            print(f"\n[*] Fetching URLs from Wayback Machine for: {self.domain}")
        
        try:
            # Wayback Machine CDX API
            api_url = f"https://web.archive.org/cdx/search/cdx?url=*.{self.domain}/*&output=json&fl=original&collapse=urlkey"
            
            response = self.session.get(api_url, timeout=30)
            
            if response.status_code == 200:
                data = response.json()
                
                # Skip header row
                for row in data[1:]:
                    if row and len(row) > 0:
                        url = row[0]
                        self.wayback_urls.append(url)
                        
                        # Extract unique endpoints
                        parsed = urlparse(url)
                        if parsed.path and parsed.path != '/':
                            self.unique_endpoints.add(parsed.path)
                        
                        # Find interesting files
                        if any(ext in url.lower() for ext in ['.php', '.asp', '.aspx', '.jsp', '.bak', '.old', '.zip', '.tar', '.gz', '.sql', '.env', '.config', '.log']):
                            self.interesting_files.append(url)
                
                if self.verbose:
                    print(f"  [✓] Found {len(self.wayback_urls)} URLs")
                    print(f"  [✓] Unique endpoints: {len(self.unique_endpoints)}")
                    print(f"  [✓] Interesting files: {len(self.interesting_files)}")
                
                return self.wayback_urls
            else:
                if self.verbose:
                    print(f"  [✗] API Error: {response.status_code}")
                return []
                
        except Exception as e:
            if self.verbose:
                print(f"  [✗] Error: {e}")
            return []
    
    def scan(self):
        self.fetch_wayback_urls()
        return self.wayback_urls
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  📅 WAYBACK MACHINE RESULTS")
        print(f"{'='*50}")
        print(f"  Domain: {self.domain}")
        print(f"  Total URLs: {len(self.wayback_urls)}")
        print(f"  Unique Endpoints: {len(self.unique_endpoints)}")
        print(f"  Interesting Files: {len(self.interesting_files)}")
        
        if self.interesting_files:
            print(f"\n  🔴 Interesting/Old Files:")
            for url in self.interesting_files[:20]:
                print(f"    • {url[:100]}")
            if len(self.interesting_files) > 20:
                print(f"    ... and {len(self.interesting_files) - 20} more")
        
        if self.unique_endpoints:
            print(f"\n  📂 Unique Endpoints (first 30):")
            for ep in sorted(list(self.unique_endpoints))[:30]:
                print(f"    • {ep}")
            if len(self.unique_endpoints) > 30:
                print(f"    ... and {len(self.unique_endpoints) - 30} more")
        
        print(f"{'='*50}")
