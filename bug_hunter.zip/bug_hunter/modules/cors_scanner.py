import requests
from urllib.parse import urlparse
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class CORSScanner:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        self.cors_vulnerable = False
        self.cors_details = {}
        
        # Parse domain for evil origin test
        parsed = urlparse(self.url)
        self.test_origins = [
            'https://evil.com',
            'https://attacker.com',
            'null',
            'https://example.com',
            f'https://evil.{parsed.netloc}',
            'http://localhost',
        ]
    
    def test_cors(self, origin):
        """Test CORS with specific origin"""
        headers = {
            'Origin': origin,
            'User-Agent': 'BugHunter/2.0'
        }
        
        # Add custom headers from config
        if self.config.get('headers'):
            headers.update(self.config['headers'])
        
        try:
            response = self.session.get(self.url, headers=headers, timeout=10)
            
            acao = response.headers.get('Access-Control-Allow-Origin', '')
            acac = response.headers.get('Access-Control-Allow-Credentials', '')
            
            return {
                'origin': origin,
                'status': response.status_code,
                'acao': acao,
                'acac': acac,
                'vulnerable': (acao == origin or acao == '*') and acac.lower() == 'true'
            }
        except Exception as e:
            return None
    
    def scan(self):
        """Test CORS misconfiguration"""
        if self.verbose:
            print(f"\n[*] Testing CORS misconfiguration on: {self.url}")
        
        for origin in self.test_origins:
            result = self.test_cors(origin)
            if result:
                self.cors_details[origin] = result
                
                if result['vulnerable']:
                    self.cors_vulnerable = True
                    if self.verbose:
                        print(f"  {Fore.RED}[⚠] VULNERABLE: Origin={origin}{Style.RESET_ALL}")
                        print(f"       ACAO={result['acao']}, ACAC={result['acac']}")
                else:
                    if self.verbose:
                        print(f"  [✓] Safe: Origin={origin} -> ACAO={result['acao'] or 'None'}")
        
        return self.cors_vulnerable
    
    def display_results(self):
        """Display CORS scan results"""
        print(f"\n{'='*50}")
        print(f"  🔓 CORS SCANNER RESULTS")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        
        if self.cors_vulnerable:
            print(f"\n  {Fore.RED}🔴 CORS VULNERABLE!{Style.RESET_ALL}")
            print(f"  The server accepts arbitrary origins with credentials.")
            print(f"  This could allow cross-origin attacks.")
        else:
            print(f"\n  {Fore.GREEN}✅ CORS appears safe{Style.RESET_ALL}")
        
        print(f"\n  📋 Test Results:")
        for origin, details in self.cors_details.items():
            icon = "🔴" if details['vulnerable'] else "🟢"
            print(f"    {icon} Origin: {origin}")
            print(f"       Status: {details['status']}")
            print(f"       ACAO: {details['acao'] or 'Not set'}")
            print(f"       ACAC: {details['acac'] or 'Not set'}")
            print()
        
        print(f"{'='*50}")
