import requests
import time
from urllib.parse import urljoin
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class RateLimitChecker:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        self.endpoints_to_test = [
            '/login',
            '/signin',
            '/signup',
            '/register',
            '/api/login',
            '/api/auth',
            '/wp-login.php',
        ]
        
        self.results = {}
        self.vulnerable_endpoints = []
    
    def test_endpoint(self, endpoint, num_requests=20):
        """Test rate limiting on an endpoint"""
        full_url = urljoin(self.url, endpoint)
        
        results = []
        blocked = False
        
        for i in range(num_requests):
            try:
                start_time = time.time()
                response = self.session.get(full_url, timeout=10)
                elapsed = time.time() - start_time
                
                results.append({
                    'request': i + 1,
                    'status': response.status_code,
                    'elapsed': round(elapsed, 2),
                    'size': len(response.content)
                })
                
                # Check if blocked
                if response.status_code in [429, 403, 503]:
                    blocked = True
                    if self.verbose:
                        print(f"  {Fore.GREEN}[✓] Rate limited at request {i+1} (Status: {response.status_code}){Style.RESET_ALL}")
                    break
                
                # Check for rate limit headers
                rl_headers = ['X-RateLimit-Remaining', 'Retry-After', 'X-RateLimit-Limit']
                for rh in rl_headers:
                    if rh in response.headers:
                        if self.verbose:
                            print(f"  {Fore.CYAN}[*] Rate limit header: {rh}={response.headers[rh]}{Style.RESET_ALL}")
                
                time.sleep(0.1)  # Small delay between requests
                
            except Exception as e:
                results.append({
                    'request': i + 1,
                    'status': 0,
                    'elapsed': 0,
                    'size': 0,
                    'error': str(e)
                })
        
        return results, blocked
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Testing rate limits on: {self.url}")
            print(f"[*] Testing {len(self.endpoints_to_test)} endpoints\n")
        
        for endpoint in self.endpoints_to_test:
            if self.verbose:
                print(f"  [*] Testing: {endpoint}")
            
            results, blocked = self.test_endpoint(endpoint, 20)
            self.results[endpoint] = results
            
            if not blocked:
                # Rate limit not implemented
                self.vulnerable_endpoints.append(endpoint)
                if self.verbose:
                    print(f"  {Fore.RED}[⚠] NO RATE LIMIT: {endpoint} (All {len(results)} requests passed){Style.RESET_ALL}")
            elif self.verbose:
                print(f"  [✓] Rate limited: {endpoint}")
        
        return self.vulnerable_endpoints
    
    def display_results(self):
        print(f"\n{'='*60}")
        print(f"  ⏱️  RATE LIMIT CHECKER")
        print(f"{'='*60}")
        print(f"  URL: {self.url}")
        
        if self.vulnerable_endpoints:
            print(f"\n  {Fore.RED}🔴 NO RATE LIMIT ({len(self.vulnerable_endpoints)}):{Style.RESET_ALL}")
            print(f"  These endpoints are vulnerable to brute force attacks.\n")
            for ep in self.vulnerable_endpoints:
                print(f"    • {ep}")
        else:
            print(f"\n  ✅ All tested endpoints have rate limiting")
        
        # Summary table
        print(f"\n  📊 Summary:")
        print(f"  {'Endpoint':<25} {'Requests':>10} {'Result':>15}")
        print(f"  {'─'*25} {'─'*10} {'─'*15}")
        for endpoint, results in self.results.items():
            statuses = [r['status'] for r in results]
            unique_statuses = set(statuses)
            result = 'BLOCKED' if 429 in unique_statuses or 403 in unique_statuses else 'VULNERABLE'
            color = Fore.GREEN if result == 'BLOCKED' else Fore.RED
            print(f"  {endpoint:<25} {len(results):>10} {color}{result:>15}{Style.RESET_ALL}")
        
        print(f"{'='*60}")
