import requests
from colorama import Fore, Style
import urllib3
from urllib.parse import urljoin
import concurrent.futures

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class DirBruteforcer:
    def __init__(self, url, wordlist=None, threads=10, config=None):
        self.url = url.rstrip('/')
        self.threads = threads
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        if 'User-Agent' not in self.session.headers:
            self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.wordlist = wordlist if wordlist else [
            'admin', 'login', 'wp-admin', 'dashboard', 'panel',
            'api', 'v1', 'v2', 'api/v1', 'api/v2',
            'backup', 'backups', 'old', 'new', 'test',
            'dev', 'upload', 'uploads', 'files', 'images',
            'css', 'js', 'assets', 'static',
            'config', 'settings', 'setup', 'install',
            'logs', 'log', 'tmp', 'temp', 'cache',
            'includes', 'database', 'db', 'sql',
            'phpmyadmin', 'phpinfo', 'info',
            '.git', '.svn', 'robots.txt', 'sitemap.xml',
            'cron', 'webhook', 'oauth', 'auth',
            'register', 'signup', 'signin', 'profile',
            'account', 'user', 'users', 'search',
            'download', 'downloads', 'private', 'hidden',
        ]
        
        self.found_dirs = []
        self.total_requests = 0
    
    def check_directory(self, directory):
        try:
            full_url = urljoin(self.url + '/', directory)
            response = self.session.get(full_url, timeout=5, allow_redirects=False)
            self.total_requests += 1
            
            if response.status_code in [200, 301, 302, 403]:
                return {
                    'url': full_url,
                    'status': response.status_code,
                    'size': len(response.content),
                }
        except:
            pass
        return None
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Bruteforcing directories on: {self.url}")
            print(f"[*] Wordlist: {len(self.wordlist)} entries, Threads: {self.threads}\n")
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(self.check_directory, dir_name): dir_name 
                      for dir_name in self.wordlist}
            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    self.found_dirs.append(result)
                    if self.verbose:
                        status = "Accessible" if result['status'] == 200 else f"Status: {result['status']}"
                        print(f"  [✓] {result['url']} ({status})")
        
        self.found_dirs.sort(key=lambda x: x['status'])
        return self.found_dirs
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  📂 DIRECTORY BRUTEFORCE RESULTS")
        print(f"{'='*50}")
        print(f"  Total Requests: {self.total_requests}")
        print(f"  Found: {len(self.found_dirs)} directories")
        
        if self.found_dirs:
            print(f"\n  Found Directories:")
            for d in self.found_dirs:
                icon = "🔴" if d['status'] == 200 else "🟡"
                print(f"    {icon} {d['url']} (Status: {d['status']})")
        
        print(f"{'='*50}")
