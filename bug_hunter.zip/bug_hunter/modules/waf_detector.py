import requests
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WAFDetector:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        if 'User-Agent' not in self.session.headers:
            self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.waf_signatures = {
            'Cloudflare': ['cloudflare', '__cfduid', 'cf-ray'],
            'AWS WAF': ['aws', 'awselb', 'x-amz-cf-id'],
            'Akamai': ['akamai', 'akamaighost'],
            'Imperva': ['imperva', 'incapsula'],
            'Sucuri': ['sucuri', 'sucuricloudproxy'],
            'F5 BIG-IP': ['f5', 'big-ip', 'bigipserver'],
            'ModSecurity': ['mod_security', 'modsecurity'],
            'Barracuda': ['barracuda'],
            'Fortinet': ['fortinet', 'fortiweb'],
            'Wordfence': ['wordfence'],
        }
        
        self.detected_waf = None
        self.waf_evidence = []
    
    def detect(self):
        if self.verbose:
            print(f"\n[*] Detecting WAF on: {self.url}")
        
        try:
            response = self.session.get(self.url, timeout=10)
            headers = response.headers
            all_headers = ' '.join([f"{k}: {v}" for k, v in headers.items()]).lower()
            
            for waf_name, signatures in self.waf_signatures.items():
                for sig in signatures:
                    if sig.lower() in all_headers:
                        self.detected_waf = waf_name
                        self.waf_evidence.append(f"Header: {sig}")
                        break
                if self.detected_waf:
                    break
            
            if not self.detected_waf:
                try:
                    test_url = f"{self.url}/?id=1' OR '1'='1"
                    test_resp = self.session.get(test_url, timeout=10)
                    
                    if test_resp.status_code in [403, 406, 429, 501, 503]:
                        block_words = ['blocked', 'forbidden', 'waf', 'firewall', 'security']
                        for word in block_words:
                            if word in test_resp.text.lower():
                                self.detected_waf = 'Generic WAF'
                                self.waf_evidence.append(f"Blocked: {word}")
                                break
                except:
                    pass
            
            if self.verbose:
                if self.detected_waf:
                    print(f"  [✓] WAF Detected: {self.detected_waf}")
                else:
                    print(f"  [✓] No WAF detected")
            
            return self.detected_waf
            
        except Exception as e:
            if self.verbose:
                print(f"[✗] Error: {e}")
            return None
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🛡️ WAF DETECTION RESULTS")
        print(f"{'='*50}")
        
        if self.detected_waf:
            print(f"\n  ⚠️  WAF Detected: {self.detected_waf}")
            if self.waf_evidence:
                print(f"\n  Evidence:")
                for e in self.waf_evidence:
                    print(f"    • {e}")
        else:
            print(f"\n  ✅ No WAF detected")
        
        print(f"{'='*50}")
