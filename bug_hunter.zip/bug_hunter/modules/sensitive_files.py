import requests
from colorama import Fore, Style
import urllib3
from urllib.parse import urljoin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SensitiveFileFinder:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        if 'User-Agent' not in self.session.headers:
            self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.sensitive_files = [
            '.git/HEAD', '.env', '.env.backup', '.env.local',
            'backup.zip', 'backup.tar.gz', 'database.sql',
            'wp-config.php', 'wp-config.bak', 'config.php',
            'config.php.bak', 'config.yml', 'config.json',
            'web.config', 'robots.txt', 'sitemap.xml',
            'phpinfo.php', 'info.php', 'test.php',
            '.htaccess', '.DS_Store', 'package.json',
            'Dockerfile', 'docker-compose.yml',
            '.gitignore', 'README.md', 'adminer.php',
        ]
        
        self.found_files = []
    
    def check_file(self, path):
        try:
            full_url = urljoin(self.url + '/', path)
            response = self.session.get(full_url, timeout=5, allow_redirects=False)
            
            if response.status_code == 200:
                return {
                    'url': full_url,
                    'status': response.status_code,
                    'size': len(response.content),
                }
            elif response.status_code in [301, 302, 403]:
                return {
                    'url': full_url,
                    'status': response.status_code,
                    'size': 0,
                }
        except:
            pass
        return None
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Scanning sensitive files on: {self.url}")
        
        for file_path in self.sensitive_files:
            if self.verbose:
                print(f"  [*] Checking: /{file_path}", end='\r')
            
            result = self.check_file(file_path)
            if result:
                self.found_files.append(result)
                if self.verbose:
                    status = "Accessible" if result['status'] == 200 else f"Status: {result['status']}"
                    print(f"  [✓] Found: /{file_path} ({status})")
        
        return self.found_files
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🗂️ SENSITIVE FILES SCAN RESULTS")
        print(f"{'='*50}")
        
        if not self.found_files:
            print(f"\n  ✅ No sensitive files found")
        else:
            accessible = [f for f in self.found_files if f['status'] == 200]
            restricted = [f for f in self.found_files if f['status'] in [301, 302, 403]]
            
            if accessible:
                print(f"\n  🔴 Accessible Files ({len(accessible)}):")
                for f in accessible:
                    print(f"    • {f['url']} ({f['size']} bytes)")
            
            if restricted:
                print(f"\n  🟡 Restricted but Exists ({len(restricted)}):")
                for f in restricted:
                    print(f"    • {f['url']} (Status: {f['status']})")
        
        print(f"{'='*50}")
