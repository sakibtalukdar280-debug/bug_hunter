import requests
import json
from datetime import datetime
from colorama import Fore, Style

class DiscordNotifier:
    def __init__(self, webhook_url, config=None):
        self.webhook_url = webhook_url
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
    
    def send_scan_start(self, target, modules):
        """Send scan start notification"""
        embed = {
            "title": "🚀 Scan Started",
            "description": f"**Target:** {target}\n**Modules:** {', '.join(modules)}",
            "color": 3447003,  # Blue
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "Bug Hunter Swiss Knife v4.0"}
        }
        return self._send({"embeds": [embed]})
    
    def send_vulnerability(self, target, vuln_type, details):
        """Send vulnerability alert"""
        embed = {
            "title": f"⚠️ Vulnerability Found!",
            "description": f"**Target:** {target}\n**Type:** {vuln_type}\n**Details:** {details}",
            "color": 15158332,  # Red
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "Bug Hunter Swiss Knife v4.0"}
        }
        return self._send({"embeds": [embed]})
    
    def send_scan_complete(self, target, results):
        """Send scan complete notification"""
        endpoints = len(results.get('endpoints', []))
        vulns = len(results.get('vulnerabilities', []))
        ports = len(results.get('open_ports', []))
        
        embed = {
            "title": "✅ Scan Completed",
            "description": f"**Target:** {target}",
            "color": 3066993,  # Green
            "fields": [
                {"name": "🔗 Endpoints", "value": str(endpoints), "inline": True},
                {"name": "⚠️ Vulnerabilities", "value": str(vulns), "inline": True},
                {"name": "🌐 Open Ports", "value": str(ports), "inline": True},
            ],
            "timestamp": datetime.now().isoformat(),
            "footer": {"text": "Bug Hunter Swiss Knife v4.0"}
        }
        return self._send({"embeds": [embed]})
    
    def send_file(self, filepath, message="Scan Report"):
        """Send a file to Discord"""
        try:
            with open(filepath, 'rb') as f:
                files = {'file': (filepath, f)}
                data = {'content': message}
                response = requests.post(self.webhook_url, data=data, files=files)
                return response.status_code == 200
        except Exception as e:
            if self.verbose:
                print(f"{Fore.RED}[✗] Discord file upload failed: {e}{Style.RESET_ALL}")
            return False
    
    def _send(self, payload):
        """Send message to Discord webhook"""
        try:
            headers = {'Content-Type': 'application/json'}
            response = requests.post(self.webhook_url, data=json.dumps(payload), headers=headers)
            
            if response.status_code == 204:
                if self.verbose:
                    print(f"{Fore.GREEN}[✓] Discord notification sent{Style.RESET_ALL}")
                return True
            else:
                if self.verbose:
                    print(f"{Fore.RED}[✗] Discord error: {response.status_code}{Style.RESET_ALL}")
                return False
        except Exception as e:
            if self.verbose:
                print(f"{Fore.RED}[✗] Discord send failed: {e}{Style.RESET_ALL}")
            return False
    
    def test_webhook(self):
        """Test if webhook is working"""
        embed = {
            "title": "🔧 Webhook Test",
            "description": "Bug Hunter Swiss Knife is connected!",
            "color": 10181046,  # Purple
            "timestamp": datetime.now().isoformat(),
        }
        return self._send({"embeds": [embed]})
