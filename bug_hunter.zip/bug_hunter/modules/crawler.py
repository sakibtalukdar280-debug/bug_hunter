import requests
import re
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
from colorama import Fore, Style
import time
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WebCrawler:
    def __init__(self, url, max_depth=3, max_urls=1000, config=None):
        self.base_url = url
        self.max_depth = max_depth
        self.max_urls = max_urls
        self.verbose = config.get('verbose', False) if config else False
        self.visited = set()
        self.endpoints = set()
        self.config = config if config else {}
        
        self.session = requests.Session()
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        if 'User-Agent' not in self.session.headers:
            self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('proxy'):
            self.session.proxies = {
                'http': self.config['proxy'],
                'https': self.config['proxy']
            }
        
        self.session.verify = False
        self.delay = self.config.get('delay', 0)
        self.base_domain = urlparse(self.base_url).netloc
    
    def is_valid_url(self, url):
        try:
            parsed = urlparse(url)
            base_parsed = urlparse(self.base_url)
            return bool(parsed.netloc) and parsed.netloc == base_parsed.netloc
        except:
            return False
    
    def is_js_code_snippet(self, url):
        js_indicators = [
            '=>', 'function(', 'document.', 'window.', 'localStorage.',
            'getElementById', 'querySelector', 'addEventListener',
            'const ', 'let ', 'var ', '===', '!==', '>=', '<=',
            'return ', 'this.', 'event.', 'preventDefault',
            'console.', 'JSON.', 'parse(', 'stringify',
            'setTimeout', 'setInterval', 'innerHTML',
            'classList', 'style.', 'textContent',
            'export ', 'import ', 'require(',
            '){', '});', '];', '}`;', "';", '"+', '"+'
        ]
        
        url_lower = url.lower()
        for indicator in js_indicators:
            if indicator.lower() in url_lower:
                return True
        return False
    
    def is_valid_endpoint(self, url):
        if len(url) > 200:
            return False
        
        if self.is_js_code_snippet(url):
            return False
        
        special_chars = ['`', '${', '=>', '===', '!==']
        for char in special_chars:
            if char in url:
                return False
        
        return True
    
    def clean_url(self, url):
        if '#' in url:
            url = url.split('#')[0]
        
        url = url.rstrip('.,;:\'"')
        
        if url.startswith(('javascript:', 'mailto:', 'tel:', 'data:')):
            return None
        
        return url
    
    def extract_links(self, url, html):
        soup = BeautifulSoup(html, 'html.parser')
        links = set()
        
        for tag in soup.find_all('a', href=True):
            href = tag.get('href', '').strip()
            if href and not href.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
                links.add(href)
        
        for tag in soup.find_all('link', href=True):
            href = tag.get('href', '').strip()
            if href:
                links.add(href)
        
        for tag in soup.find_all('script', src=True):
            src = tag.get('src', '').strip()
            if src:
                links.add(src)
        
        for tag in soup.find_all('img', src=True):
            src = tag.get('src', '').strip()
            if src:
                links.add(src)
        
        absolute_links = set()
        for link in links:
            link = link.strip()
            cleaned = self.clean_url(link)
            if cleaned is None:
                continue
            
            if cleaned.startswith(('http://', 'https://')):
                absolute_links.add(cleaned)
            elif cleaned.startswith('/'):
                absolute_links.add(urljoin(url, cleaned))
            elif cleaned.startswith('./') or cleaned.startswith('../'):
                absolute_links.add(urljoin(url, cleaned))
        
        return absolute_links
    
    def extract_endpoints(self, url, html):
        endpoints = set()
        soup = BeautifulSoup(html, 'html.parser')
        
        for form in soup.find_all('form', action=True):
            action = form.get('action', '').strip()
            if action:
                full_url = urljoin(url, action)
                if self.is_valid_endpoint(full_url):
                    endpoints.add(full_url)
        
        for tag in soup.find_all('a', href=True):
            href = tag.get('href', '').strip()
            if '?' in href:
                full_url = urljoin(url, href)
                if self.is_valid_endpoint(full_url):
                    endpoints.add(full_url)
        
        return endpoints
    
    def crawl(self):
        to_visit = [(self.base_url, 0)]
        
        while to_visit:
            if len(self.visited) >= self.max_urls:
                if self.verbose:
                    print(f"{Fore.YELLOW}[!] Reached max URLs limit ({self.max_urls}){Style.RESET_ALL}")
                break
            
            url, depth = to_visit.pop(0)
            url = self.clean_url(url)
            
            if url is None or self.is_js_code_snippet(url):
                continue
            
            if url in self.visited or depth > self.max_depth:
                continue
            
            if not self.is_valid_url(url):
                continue
            
            self.visited.add(url)
            
            try:
                if self.verbose:
                    display_url = url[:80] + '...' if len(url) > 80 else url
                    print(f"{Fore.BLUE}[*] Crawling ({len(self.visited)}/{self.max_urls}): {display_url}{Style.RESET_ALL}")
                
                response = self.session.get(url, timeout=10, allow_redirects=True)
                
                content_type = response.headers.get('Content-Type', '')
                if 'text/html' in content_type:
                    links = self.extract_links(url, response.text)
                    endpoints = self.extract_endpoints(url, response.text)
                    
                    for ep in endpoints:
                        if self.is_valid_endpoint(ep) and self.is_valid_url(ep):
                            self.endpoints.add(ep)
                    
                    for link in links:
                        if (self.is_valid_url(link) and 
                            link not in self.visited and 
                            self.is_valid_endpoint(link)):
                            if len(to_visit) < self.max_urls:
                                to_visit.append((link, depth + 1))
                else:
                    if self.is_valid_endpoint(url):
                        self.endpoints.add(url)
                
                if self.delay > 0:
                    time.sleep(self.delay)
                
            except requests.RequestException as e:
                if self.verbose:
                    print(f"{Fore.RED}[✗] Error: {url[:60]}... - {str(e)[:30]}{Style.RESET_ALL}")
                continue
            except Exception as e:
                if self.verbose:
                    print(f"{Fore.RED}[✗] Error: {url[:60]}...{Style.RESET_ALL}")
                continue
        
        filtered_endpoints = {ep for ep in self.endpoints if self.is_valid_endpoint(ep)}
        
        if self.verbose:
            print(f"{Fore.GREEN}[✓] Crawling completed. Visited: {len(self.visited)}, Endpoints: {len(filtered_endpoints)}{Style.RESET_ALL}")
        
        return list(filtered_endpoints)