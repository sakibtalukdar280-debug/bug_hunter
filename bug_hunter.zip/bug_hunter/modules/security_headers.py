import requests
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SecurityHeaders:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        self.headers = {}
        self.issues = []
        self.good = []
        self.score = 0
        self.grade = 'F'
    
    def check_header(self, header_name, expected=None, importance='Medium', description=''):
        """Check if a security header is present"""
        if header_name in self.headers:
            value = self.headers[header_name]
            if expected:
                if expected.lower() in value.lower():
                    self.good.append(f"{header_name}: {value}")
                    return True
                else:
                    self.issues.append({
                        'header': header_name,
                        'issue': f'Weak value: {value}',
                        'expected': expected,
                        'importance': importance,
                        'description': description
                    })
                    return False
            else:
                self.good.append(f"{header_name}: {value}")
                return True
        else:
            self.issues.append({
                'header': header_name,
                'issue': 'Missing',
                'expected': expected or 'Should be present',
                'importance': importance,
                'description': description
            })
            return False
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Analyzing security headers: {self.url}")
        
        try:
            response = self.session.get(self.url, timeout=10)
            self.headers = response.headers
            
            # Check critical headers
            self.check_header(
                'Content-Security-Policy',
                importance='Critical',
                description='Prevents XSS, data injection attacks'
            )
            
            self.check_header(
                'Strict-Transport-Security',
                expected='max-age',
                importance='Critical',
                description='Forces HTTPS connections'
            )
            
            self.check_header(
                'X-Frame-Options',
                expected='DENY',
                importance='High',
                description='Prevents clickjacking attacks'
            )
            
            self.check_header(
                'X-Content-Type-Options',
                expected='nosniff',
                importance='High',
                description='Prevents MIME type sniffing'
            )
            
            self.check_header(
                'Referrer-Policy',
                importance='Medium',
                description='Controls referrer information leakage'
            )
            
            self.check_header(
                'Permissions-Policy',
                importance='Medium',
                description='Controls browser feature access'
            )
            
            self.check_header(
                'Access-Control-Allow-Origin',
                importance='High',
                description='CORS policy - should not be *'
            )
            
            # Check CORS value
            acao = self.headers.get('Access-Control-Allow-Origin', '')
            if acao == '*':
                self.issues.append({
                    'header': 'Access-Control-Allow-Origin',
                    'issue': f'Wildcard (*) allows any origin',
                    'expected': 'Specific origin',
                    'importance': 'High',
                    'description': 'CORS policy too permissive'
                })
            
            # Check info disclosure
            for h in ['Server', 'X-Powered-By', 'X-AspNet-Version', 'X-AspNetMvc-Version']:
                if h in self.headers:
                    self.issues.append({
                        'header': h,
                        'issue': f'Information disclosure: {self.headers[h]}',
                        'expected': 'Should be removed',
                        'importance': 'Low',
                        'description': 'Reveals server technology'
                    })
            
            # Calculate score
            total_checks = 10
            passed = len(self.good)
            self.score = int((passed / total_checks) * 100)
            
            if self.score >= 90: self.grade = 'A'
            elif self.score >= 80: self.grade = 'B'
            elif self.score >= 70: self.grade = 'C'
            elif self.score >= 60: self.grade = 'D'
            else: self.grade = 'F'
            
            return self.headers
            
        except Exception as e:
            if self.verbose:
                print(f"[✗] Error: {e}")
            return {}
    
    def display_results(self):
        print(f"\n{'='*60}")
        print(f"  🔒 SECURITY HEADERS ANALYSIS")
        print(f"{'='*60}")
        print(f"  URL: {self.url}")
        print(f"  Grade: {self.grade} | Score: {self.score}/100")
        
        # Grade bar
        grade_colors = {'A': Fore.GREEN, 'B': Fore.GREEN, 'C': Fore.YELLOW, 'D': Fore.RED, 'F': Fore.RED}
        print(f"  {grade_colors.get(self.grade, Fore.RED)}[{'█'*(self.score//10)}{'░'*(10-self.score//10)}]{Style.RESET_ALL}")
        
        if self.issues:
            critical = [i for i in self.issues if i['importance'] == 'Critical']
            high = [i for i in self.issues if i['importance'] == 'High']
            medium = [i for i in self.issues if i['importance'] == 'Medium']
            low = [i for i in self.issues if i['importance'] == 'Low']
            
            if critical:
                print(f"\n  🔴 CRITICAL Issues ({len(critical)}):")
                for i in critical:
                    print(f"    • {i['header']}: {i['issue']}")
                    print(f"      ➜ {i['description']}")
            
            if high:
                print(f"\n  🟠 HIGH Issues ({len(high)}):")
                for i in high:
                    print(f"    • {i['header']}: {i['issue']}")
            
            if medium:
                print(f"\n  🟡 MEDIUM Issues ({len(medium)}):")
                for i in medium:
                    print(f"    • {i['header']}: {i['issue']}")
            
            if low:
                print(f"\n  ⚪ LOW Issues ({len(low)}):")
                for i in low:
                    print(f"    • {i['header']}: {i['issue']}")
        
        if self.good:
            print(f"\n  ✅ Good Headers:")
            for g in self.good:
                print(f"    • {g}")
        
        print(f"{'='*60}")
