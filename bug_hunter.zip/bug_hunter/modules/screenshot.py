import requests
import base64
from colorama import Fore, Style
import urllib3
import os
from datetime import datetime

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class ScreenshotCapture:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.screenshot_data = None
    
    def capture_via_api(self):
        """Capture screenshot using free API"""
        if self.verbose:
            print(f"\n[*] Capturing screenshot of: {self.url}")
        
        try:
            # Using thum.io free service (limited)
            api_url = f"https://image.thum.io/get/width/1200/crop/800/https://{self.url.replace('https://', '').replace('http://', '')}"
            
            response = requests.get(api_url, timeout=30)
            
            if response.status_code == 200:
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                filename = f"screenshot_{timestamp}.png"
                
                with open(filename, 'wb') as f:
                    f.write(response.content)
                
                if self.verbose:
                    print(f"  [✓] Screenshot saved: {filename}")
                
                return filename
            else:
                if self.verbose:
                    print(f"  [✗] API Error: {response.status_code}")
                return None
                
        except Exception as e:
            if self.verbose:
                print(f"  [✗] Error: {e}")
            return None
    
    def capture_basic(self):
        """Capture page info without actual screenshot (fallback)"""
        if self.verbose:
            print(f"\n[*] Capturing page info for: {self.url}")
        
        try:
            session = requests.Session()
            session.verify = False
            session.headers['User-Agent'] = 'BugHunter/2.0'
            
            response = session.get(self.url, timeout=10)
            
            info = {
                'url': self.url,
                'status': response.status_code,
                'title': 'N/A',
                'size': len(response.content),
                'server': response.headers.get('Server', 'Unknown'),
                'content_type': response.headers.get('Content-Type', 'Unknown'),
            }
            
            # Extract title
            import re
            title_match = re.search(r'<title>(.*?)</title>', response.text, re.IGNORECASE)
            if title_match:
                info['title'] = title_match.group(1)[:100]
            
            return info
            
        except Exception as e:
            if self.verbose:
                print(f"  [✗] Error: {e}")
            return None
    
    def capture(self):
        """Try API first, fallback to basic info"""
        result = self.capture_via_api()
        
        if not result:
            if self.verbose:
                print(f"  [!] Screenshot API unavailable, capturing page info...")
            info = self.capture_basic()
            if info:
                self.page_info = info
        
        return result
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  📸 SCREENSHOT CAPTURE RESULTS")
        print(f"{'='*50}")
        
        if hasattr(self, 'page_info'):
            info = self.page_info
            print(f"\n  Page Information:")
            print(f"    URL: {info['url']}")
            print(f"    Status: {info['status']}")
            print(f"    Title: {info['title']}")
            print(f"    Size: {info['size']} bytes")
            print(f"    Server: {info['server']}")
            print(f"    Content: {info['content_type']}")
        
        print(f"{'='*50}")
