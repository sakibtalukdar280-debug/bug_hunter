import requests
import re
from urllib.parse import urljoin
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class JSAnalyzer:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        # Patterns to search in JS
        self.patterns = {
            'API Keys': [
                r'(?:api[_-]?key|apikey)["\s:=]+["\']([a-zA-Z0-9_\-]{20,})["\']',
                r'(?:api[_-]?secret|apisecret)["\s:=]+["\']([a-zA-Z0-9_\-]{20,})["\']',
            ],
            'Tokens': [
                r'(?:token|access[_-]?token)["\s:=]+["\']([a-zA-Z0-9_\-\.]{20,})["\']',
                r'(?:bearer|jwt)["\s:=]+["\']([a-zA-Z0-9_\-\.]{20,})["\']',
            ],
            'AWS Keys': [
                r'AKIA[0-9A-Z]{16}',
                r'(?:aws[_-]?secret)["\s:=]+["\']([a-zA-Z0-9+/]{40})["\']',
            ],
            'Google API': [
                r'AIza[0-9A-Za-z\-_]{35}',
            ],
            'GitHub Tokens': [
                r'(?:gh[pt]_[a-zA-Z0-9]{36})',
                r'(?:github[_-]?token)["\s:=]+["\']([a-zA-Z0-9_\-]{40})["\']',
            ],
            'Private Keys': [
                r'-----BEGIN (?:RSA |EC )?PRIVATE KEY-----',
            ],
            'URLs/Endpoints': [
                r'(?:url|endpoint|api|host|baseURL)["\s:=]+["\'](https?://[^\s"\']+)["\']',
            ],
            'Firebase': [
                r'(?:firebase|project[_-]?id)["\s:=]+["\']([a-zA-Z0-9\-]+)["\']',
            ],
            'Passwords': [
                r'(?:password|passwd|pwd)["\s:=]+["\']([^"\']{4,})["\']',
            ],
        }
        
        self.findings = []
        self.js_files = []
    
    def extract_js_files(self, html):
        """Extract JavaScript file URLs"""
        js_files = []
        pattern = r'<script[^>]+src=["\']([^"\']+\.js[^"\']*)["\']'
        matches = re.findall(pattern, html, re.IGNORECASE)
        for match in matches:
            js_files.append(urljoin(self.url, match))
        return list(set(js_files))
    
    def analyze_js(self, js_url):
        """Analyze a JavaScript file"""
        try:
            response = self.session.get(js_url, timeout=10)
            content = response.text
            
            file_findings = []
            
            for category, patterns in self.patterns.items():
                for pattern in patterns:
                    matches = re.findall(pattern, content, re.IGNORECASE)
                    for match in matches:
                        if isinstance(match, tuple):
                            match = match[0]
                        if len(match) > 5:  # Filter noise
                            file_findings.append({
                                'category': category,
                                'value': match[:80],
                                'file': js_url
                            })
            
            return file_findings
            
        except Exception as e:
            if self.verbose:
                print(f"  [✗] Error: {js_url[:60]} - {e}")
            return []
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Analyzing JavaScript files on: {self.url}")
        
        try:
            # Get main page
            response = self.session.get(self.url, timeout=10)
            self.js_files = self.extract_js_files(response.text)
            
            if self.verbose:
                print(f"[*] Found {len(self.js_files)} JS files\n")
            
            # Analyze each JS file
            for js_url in self.js_files:
                if self.verbose:
                    print(f"  [*] Analyzing: {js_url[:80]}")
                
                findings = self.analyze_js(js_url)
                self.findings.extend(findings)
                
                for finding in findings:
                    if self.verbose:
                        print(f"    [✓] {finding['category']}: {finding['value'][:50]}")
            
            # Also analyze inline scripts
            inline_pattern = r'<script[^>]*>([\s\S]*?)</script>'
            inline_scripts = re.findall(inline_pattern, response.text, re.IGNORECASE)
            
            for script in inline_scripts:
                for category, patterns in self.patterns.items():
                    for pattern in patterns:
                        matches = re.findall(pattern, script, re.IGNORECASE)
                        for match in matches:
                            if isinstance(match, tuple):
                                match = match[0]
                            if len(match) > 5:
                                self.findings.append({
                                    'category': category,
                                    'value': match[:80],
                                    'file': 'Inline Script'
                                })
            
            return self.findings
            
        except Exception as e:
            if self.verbose:
                print(f"[✗] Error: {e}")
            return []
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🔍 JAVASCRIPT ANALYSIS RESULTS")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        print(f"  JS Files Found: {len(self.js_files)}")
        print(f"  Secrets Found: {len(self.findings)}")
        
        if self.findings:
            # Group by category
            categories = {}
            for finding in self.findings:
                cat = finding['category']
                if cat not in categories:
                    categories[cat] = []
                categories[cat].append(finding)
            
            for category, items in categories.items():
                print(f"\n  {Fore.RED if 'Key' in category or 'Token' in category or 'Password' in category else Fore.YELLOW}{category} ({len(items)}):{Style.RESET_ALL}")
                for item in items[:5]:  # Show max 5 per category
                    print(f"    • {item['value']}")
                    print(f"      File: {item['file'][:60]}")
                if len(items) > 5:
                    print(f"    ... and {len(items) - 5} more")
        else:
            print(f"\n  ✅ No secrets found in JavaScript files")
        
        print(f"{'='*50}")
