import requests
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SubdomainTakeover:
    def __init__(self, subdomains, config=None):
        self.subdomains = subdomains if isinstance(subdomains, list) else [subdomains]
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        # Known takeover signatures
        self.takeover_signatures = {
            'AWS S3': 'The specified bucket does not exist',
            'GitHub Pages': "There isn't a GitHub Pages site here",
            'Heroku': "No such app",
            'Shopify': "Sorry, this shop is currently unavailable",
            'Tumblr': "There's nothing here",
            'WordPress': "Do you want to register",
            'Zendesk': "Help Center Closed",
            'Azure': "This page isn't working",
            'Netlify': "Not Found - Netlify",
            'Vercel': "DEPLOYMENT_NOT_FOUND",
            'CloudFront': "The request could not be satisfied",
            'Fastly': "Fastly error: unknown domain",
            'Pantheon': "This site is currently offline",
            'Acquia': "This site is currently offline",
            'Readme': "Project doesn't exist",
        }
        
        self.vulnerable_subdomains = []
    
    def check_takeover(self, subdomain):
        """Check if subdomain is vulnerable to takeover"""
        try:
            url = f"https://{subdomain}"
            response = self.session.get(url, timeout=10, allow_redirects=False)
            
            # Check for error signatures
            for service, signature in self.takeover_signatures.items():
                if signature.lower() in response.text.lower():
                    return {
                        'subdomain': subdomain,
                        'service': service,
                        'signature': signature,
                        'status': response.status_code
                    }
            
            # Check for CNAME errors
            if response.status_code in [404, 500, 502, 503]:
                # Common error page indicators
                error_indicators = ['not found', 'doesn\'t exist', 'no such', 'unavailable']
                for indicator in error_indicators:
                    if indicator in response.text.lower():
                        return {
                            'subdomain': subdomain,
                            'service': 'Unknown',
                            'signature': indicator,
                            'status': response.status_code
                        }
            
        except requests.exceptions.ConnectionError:
            return {
                'subdomain': subdomain,
                'service': 'DNS/Connection',
                'signature': 'Connection failed - possibly dangling DNS',
                'status': 0
            }
        except:
            pass
        
        return None
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Checking subdomain takeover: {len(self.subdomains)} subdomains\n")
        
        for subdomain in self.subdomains:
            result = self.check_takeover(subdomain)
            if result:
                self.vulnerable_subdomains.append(result)
                if self.verbose:
                    print(f"  {Fore.RED}[⚠] TAKEOVER POSSIBLE: {subdomain}{Style.RESET_ALL}")
                    print(f"       Service: {result['service']}")
            elif self.verbose:
                print(f"  [✓] Safe: {subdomain}")
        
        return self.vulnerable_subdomains
    
    def display_results(self):
        print(f"\n{'='*60}")
        print(f"  🌐 SUBDOMAIN TAKEOVER CHECK")
        print(f"{'='*60}")
        print(f"  Checked: {len(self.subdomains)} subdomains")
        
        if self.vulnerable_subdomains:
            print(f"\n  {Fore.RED}🔴 POSSIBLE TAKEOVERS ({len(self.vulnerable_subdomains)}):{Style.RESET_ALL}\n")
            for v in self.vulnerable_subdomains:
                print(f"    • {v['subdomain']}")
                print(f"      Service: {v['service']}")
                print(f"      Status: {v['status']}")
                print(f"      Evidence: {v['signature']}")
                print()
        else:
            print(f"\n  ✅ No takeover vulnerabilities found")
        
        print(f"{'='*60}")
