import requests
import concurrent.futures
from datetime import datetime
from colorama import Fore, Style
import urllib3
import json
import os

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class MultiTargetScanner:
    def __init__(self, targets, config=None):
        self.targets = targets if isinstance(targets, list) else [t.strip() for t in targets.split('\n') if t.strip()]
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.results = {}
        self.start_time = None
        self.end_time = None
    
    def scan_single_target(self, target):
        """Scan a single target with basic checks"""
        result = {
            'url': target,
            'status': 'unknown',
            'response_code': 0,
            'technologies': [],
            'open_ports': [],
            'vulnerabilities': [],
            'timestamp': datetime.now().isoformat()
        }
        
        try:
            # Basic HTTP check
            session = requests.Session()
            session.verify = False
            session.headers['User-Agent'] = 'BugHunter/4.0 Multi-Scanner'
            
            # Try HTTPS first, then HTTP
            for protocol in ['https://', 'http://']:
                url = target if target.startswith('http') else f"{protocol}{target}"
                try:
                    response = session.get(url, timeout=15)
                    result['status'] = 'alive'
                    result['response_code'] = response.status_code
                    result['url'] = url
                    result['size'] = len(response.content)
                    result['server'] = response.headers.get('Server', 'Unknown')
                    result['content_type'] = response.headers.get('Content-Type', 'Unknown')
                    
                    # Quick tech detection
                    tech_indicators = {
                        'WordPress': ['wp-content', 'wp-json', 'wordpress'],
                        'PHP': ['php', 'PHPSESSID'],
                        'Node.js': ['node', 'express'],
                        'React': ['react', '__REACT_'],
                        'Angular': ['angular', 'ng-'],
                        'Vue.js': ['vue', 'v-bind'],
                        'jQuery': ['jquery'],
                        'Bootstrap': ['bootstrap'],
                        'Cloudflare': ['cloudflare', '__cfduid'],
                        'AWS': ['aws', 'amazonaws'],
                        'Netlify': ['netlify'],
                    }
                    
                    response_text = response.text.lower()[:5000]
                    for tech, indicators in tech_indicators.items():
                        for indicator in indicators:
                            if indicator in response_text:
                                result['technologies'].append(tech)
                                break
                    
                    # Check security headers
                    security_headers = [
                        'Strict-Transport-Security',
                        'Content-Security-Policy',
                        'X-Frame-Options',
                        'X-Content-Type-Options'
                    ]
                    for header in security_headers:
                        if header in response.headers:
                            result[header] = response.headers[header]
                    
                    break  # Success, no need to try other protocol
                    
                except:
                    continue
            
            if self.verbose:
                status_color = Fore.GREEN if result['status'] == 'alive' else Fore.RED
                print(f"  {status_color}[{result['status'].upper()}]{Style.RESET_ALL} {result['url']} ({result['response_code']})")
            
        except Exception as e:
            result['status'] = 'error'
            result['error'] = str(e)
            if self.verbose:
                print(f"  {Fore.RED}[ERROR]{Style.RESET_ALL} {target}: {str(e)[:50]}")
        
        return result
    
    def scan(self):
        """Scan all targets"""
        self.start_time = datetime.now()
        
        if self.verbose:
            print(f"\n{Fore.CYAN}[*] Multi-Target Scanner{Style.RESET_ALL}")
            print(f"{Fore.CYAN}[*] Targets: {len(self.targets)}{Style.RESET_ALL}")
            print(f"{Fore.CYAN}[*] Started: {self.start_time.strftime('%H:%M:%S')}{Style.RESET_ALL}\n")
        
        # Use ThreadPool for parallel scanning
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            futures = {executor.submit(self.scan_single_target, target): target 
                      for target in self.targets}
            
            for future in concurrent.futures.as_completed(futures):
                target = futures[future]
                try:
                    result = future.result()
                    self.results[target] = result
                except Exception as e:
                    self.results[target] = {'url': target, 'status': 'error', 'error': str(e)}
        
        self.end_time = datetime.now()
        
        return self.results
    
    def display_results(self):
        """Display scan results"""
        duration = (self.end_time - self.start_time).total_seconds() if self.end_time else 0
        
        print(f"\n{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  🎯 MULTI-TARGET SCAN RESULTS{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
        print(f"  Total Targets: {len(self.targets)}")
        print(f"  Duration: {duration:.2f} seconds")
        
        alive = [r for r in self.results.values() if r['status'] == 'alive']
        dead = [r for r in self.results.values() if r['status'] != 'alive']
        
        print(f"  Alive: {Fore.GREEN}{len(alive)}{Style.RESET_ALL}")
        print(f"  Dead/Error: {Fore.RED}{len(dead)}{Style.RESET_ALL}")
        
        if alive:
            print(f"\n{Fore.GREEN}  ✅ Alive Targets:{Style.RESET_ALL}")
            for r in alive:
                print(f"\n    • {r['url']}")
                print(f"      Status: {r['response_code']} | Server: {r.get('server', 'N/A')}")
                if r.get('technologies'):
                    print(f"      Tech: {', '.join(r['technologies'][:5])}")
        
        if dead:
            print(f"\n{Fore.RED}  ❌ Dead/Error Targets:{Style.RESET_ALL}")
            for r in dead[:10]:
                print(f"    • {r['url']} - {r.get('error', 'No response')[:50]}")
        
        print(f"{Fore.CYAN}{'='*60}{Style.RESET_ALL}")
    
    def save_results(self, filename=None):
        """Save results to JSON"""
        if not filename:
            filename = f"multi_scan_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        return filename
