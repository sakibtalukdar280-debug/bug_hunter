import requests
import re
import xml.etree.ElementTree as ET
from urllib.parse import urljoin
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SitemapParser:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.sitemap_urls = [
            '/sitemap.xml',
            '/sitemap_index.xml',
            '/sitemap.php',
            '/sitemap.txt',
            '/sitemap.xml.gz',
        ]
        
        self.all_urls = []
        self.sitemaps_found = []
    
    def parse_sitemap(self, sitemap_url):
        """Parse a sitemap XML file"""
        urls = []
        try:
            response = self.session.get(sitemap_url, timeout=10)
            
            if 'xml' in response.headers.get('Content-Type', ''):
                root = ET.fromstring(response.content)
                
                # Handle sitemap index
                if 'sitemapindex' in root.tag.lower():
                    if self.verbose:
                        print(f"  [*] Found sitemap index")
                    
                    for sitemap in root.findall('{http://www.sitemaps.org/schemas/sitemap/0.9}sitemap'):
                        loc = sitemap.find('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')
                        if loc is not None and loc.text:
                            sub_urls = self.parse_sitemap(loc.text)
                            urls.extend(sub_urls)
                
                # Handle regular sitemap
                else:
                    for url in root.findall('{http://www.sitemaps.org/schemas/sitemap/0.9}url'):
                        loc = url.find('{http://www.sitemaps.org/schemas/sitemap/0.9}loc')
                        if loc is not None and loc.text:
                            urls.append(loc.text)
            
            elif 'text/plain' in response.headers.get('Content-Type', ''):
                urls = [line.strip() for line in response.text.split('\n') 
                       if line.strip() and line.strip().startswith('http')]
            
            return urls
            
        except Exception as e:
            if self.verbose:
                print(f"  [✗] Error parsing {sitemap_url}: {e}")
            return []
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Parsing sitemaps for: {self.url}")
        
        for sitemap_path in self.sitemap_urls:
            sitemap_url = urljoin(self.url, sitemap_path)
            
            try:
                response = self.session.head(sitemap_url, timeout=5)
                if response.status_code == 200:
                    self.sitemaps_found.append(sitemap_url)
                    
                    if self.verbose:
                        print(f"  [✓] Found: {sitemap_url}")
                    
                    urls = self.parse_sitemap(sitemap_url)
                    self.all_urls.extend(urls)
                    
            except:
                pass
        
        # Remove duplicates
        self.all_urls = list(set(self.all_urls))
        
        return self.all_urls
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🗺️ SITEMAP PARSER RESULTS")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        print(f"  Sitemaps Found: {len(self.sitemaps_found)}")
        print(f"  URLs Extracted: {len(self.all_urls)}")
        
        if self.sitemaps_found:
            print(f"\n  📄 Sitemap Files:")
            for s in self.sitemaps_found:
                print(f"    • {s}")
        
        if self.all_urls:
            print(f"\n  🔗 Extracted URLs (first 30):")
            for url in self.all_urls[:30]:
                print(f"    • {url}")
            if len(self.all_urls) > 30:
                print(f"    ... and {len(self.all_urls) - 30} more")
        
        print(f"{'='*50}")
