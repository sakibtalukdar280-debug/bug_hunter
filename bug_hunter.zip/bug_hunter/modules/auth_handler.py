import requests
import json
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class AuthHandler:
    def __init__(self, base_url, config=None):
        self.base_url = base_url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        if 'User-Agent' not in self.session.headers:
            self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.local_storage = {}
        self.extracted_cookies = None
    
    def register(self, name, email, phone, password, role='buyer', shop_name=None, shop_address=None):
        """Register a new user"""
        user_data = {
            'fullName': name,
            'email': email,
            'phone': phone,
            'password': password,
            'role': role,
            'createdAt': None
        }
        
        if role == 'seller':
            user_data['shopName'] = shop_name
            user_data['shopAddress'] = shop_address
        
        if self.verbose:
            print(f"[*] Registering user: {email}")
        
        self.local_storage['bazar_users'] = self.local_storage.get('bazar_users', [])
        
        for user in self.local_storage['bazar_users']:
            if user['email'] == email:
                if self.verbose:
                    print(f"[!] User already exists: {email}")
                return user
        
        self.local_storage['bazar_users'].append(user_data)
        
        if self.verbose:
            print(f"[✓] Registered: {email}")
        
        return user_data
    
    def login(self, email, password):
        """Login with email and password"""
        if self.verbose:
            print(f"[*] Logging in: {email}")
        
        users = self.local_storage.get('bazar_users', [])
        
        for user in users:
            if user['email'] == email and user['password'] == password:
                session_data = {
                    'email': user['email'],
                    'fullName': user.get('fullName', 'User'),
                    'role': user.get('role', 'buyer'),
                    'loggedInAt': None
                }
                
                self.local_storage['bazar_session'] = session_data
                
                if self.verbose:
                    print(f"[✓] Logged in: {email}")
                
                return session_data
        
        if self.verbose:
            print(f"[✗] Invalid credentials")
        
        return None
    
    def get_session(self):
        """Get current session data"""
        return self.local_storage.get('bazar_session', {})
    
    def get_session_string(self):
        """Get session as string for tool config"""
        session = self.get_session()
        if session:
            return f"bazar_session={json.dumps(session)}"
        return ""
    
    def logout(self):
        """Clear session"""
        self.local_storage.pop('bazar_session', None)
        if self.verbose:
            print("[✓] Logged out")
    
    def auto_extract_cookies(self, url):
        """Auto extract cookies from URL"""
        try:
            response = self.session.get(url, timeout=10)
            
            # Check Set-Cookie header
            if 'Set-Cookie' in response.headers:
                cookies = response.headers['Set-Cookie']
                cookie_parts = cookies.split(';')
                extracted = []
                for part in cookie_parts:
                    if '=' in part and not any(x in part.lower() for x in ['path', 'domain', 'expires', 'max-age', 'httponly', 'secure', 'samesite']):
                        extracted.append(part.strip())
                
                if extracted:
                    self.extracted_cookies = '; '.join(extracted)
                    return self.extracted_cookies
            
            # Check session cookies
            all_cookies = self.session.cookies.get_dict()
            if all_cookies:
                cookie_parts = [f"{k}={v}" for k, v in all_cookies.items()]
                self.extracted_cookies = '; '.join(cookie_parts)
                return self.extracted_cookies
            
            return None
        except Exception as e:
            if self.verbose:
                print(f"[✗] Cookie extraction error: {e}")
            return None