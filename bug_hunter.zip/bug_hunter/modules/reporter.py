"""
HTML Report Generator for Bug Hunter
"""

import os
import json
from datetime import datetime

class ReportGenerator:
    def __init__(self, results=None):
        self.results = results if results else {
            'scan_info': {},
            'endpoints': [],
            'vulnerabilities': [],
            'open_ports': [],
            'technologies': {},
            'sensitive_files': [],
            'directories': [],
            'waf': None
        }
    
    @staticmethod
    def save_scan_data(results, filename=None):
        """Save scan results to JSON file"""
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"scan_{timestamp}.json"
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        return filename
    
    @staticmethod
    def load_scan_data(filename):
        """Load scan data from JSON file"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return None
    
    @staticmethod
    def list_saved_scans(directory='.'):
        """List all saved scan files with details"""
        scans = []
        for file in os.listdir(directory):
            if file.startswith('scan_') and file.endswith('.json'):
                try:
                    filepath = os.path.join(directory, file)
                    with open(filepath, 'r') as f:
                        data = json.load(f)
                        timestamp = data.get('scan_info', {}).get('timestamp', 'Unknown')
                        target = data.get('scan_info', {}).get('command', 'Unknown')
                        endpoints = len(data.get('endpoints', []))
                        vulns = len(data.get('vulnerabilities', []))
                        ports = len(data.get('open_ports', []))
                        
                        try:
                            dt = datetime.fromisoformat(timestamp)
                            formatted_time = dt.strftime('%Y-%m-%d %H:%M:%S')
                        except:
                            formatted_time = timestamp
                        
                        scans.append({
                            'file': file,
                            'filepath': filepath,
                            'timestamp': formatted_time,
                            'target': target[:80],
                            'endpoints': endpoints,
                            'vulns': vulns,
                            'ports': ports
                        })
                except:
                    pass
        
        scans.sort(key=lambda x: x['timestamp'], reverse=True)
        return scans
    
    @staticmethod
    def delete_scan_file(filename):
        """Delete a scan JSON file"""
        try:
            os.remove(filename)
            return True
        except:
            return False
    
    def generate_html(self, filename=None):
        """Generate professional HTML report"""
        if filename is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"report_{timestamp}.html"
        
        endpoints = self.results.get('endpoints', [])
        vulnerabilities = self.results.get('vulnerabilities', [])
        open_ports = self.results.get('open_ports', [])
        technologies = self.results.get('technologies', {})
        sensitive_files = self.results.get('sensitive_files', [])
        directories = self.results.get('directories', [])
        waf = self.results.get('waf', None)
        scan_info = self.results.get('scan_info', {})
        
        real_vulns = [v for v in vulnerabilities if 'No vulnerabilities' not in v]
        
        def get_severity(vuln):
            vuln_upper = vuln.upper()
            if any(x in vuln_upper for x in ['CRITICAL', 'RCE', 'SHELL']):
                return 'critical', '#e53e3e'
            elif any(x in vuln_upper for x in ['HIGH', 'SQLI', 'AUTH BYPASS']):
                return 'high', '#dd6b20'
            elif any(x in vuln_upper for x in ['MEDIUM', 'XSS', 'REDIRECT']):
                return 'medium', '#d69e2e'
            elif any(x in vuln_upper for x in ['LOW', 'INFO']):
                return 'low', '#38a169'
            else:
                return 'info', '#3182ce'
        
        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bug Hunter Report</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #0f172a; color: #e2e8f0; min-height: 100vh; }}
        .container {{ max-width: 1400px; margin: 0 auto; padding: 20px; }}
        .header {{ background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); border: 1px solid #334155; border-radius: 16px; padding: 40px; margin-bottom: 30px; }}
        .header h1 {{ font-size: 2.5em; background: linear-gradient(135deg, #60a5fa, #a78bfa); -webkit-background-clip: text; -webkit-text-fill-color: transparent; margin-bottom: 10px; }}
        .header .subtitle {{ color: #94a3b8; font-size: 1.1em; }}
        .header .meta {{ margin-top: 20px; display: flex; gap: 30px; flex-wrap: wrap; color: #64748b; }}
        .stats-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px; }}
        .stat-card {{ background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 25px; transition: all 0.3s; }}
        .stat-card:hover {{ transform: translateY(-5px); border-color: #60a5fa; }}
        .stat-card .number {{ font-size: 3em; font-weight: bold; margin-bottom: 5px; }}
        .stat-card .label {{ color: #94a3b8; }}
        .section {{ background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 30px; margin-bottom: 25px; }}
        .section h2 {{ color: #e2e8f0; margin-bottom: 20px; padding-bottom: 10px; border-bottom: 2px solid #334155; }}
        .vuln-card {{ padding: 15px; margin-bottom: 12px; border-radius: 8px; border-left: 4px solid; font-family: 'Courier New', monospace; font-size: 0.9em; }}
        .endpoint-item {{ display: flex; align-items: center; padding: 12px; background: #0f172a; border-radius: 8px; font-family: 'Courier New', monospace; font-size: 0.85em; margin-bottom: 8px; }}
        .method-badge {{ display: inline-block; padding: 3px 10px; border-radius: 4px; font-size: 0.75em; font-weight: bold; margin-right: 12px; min-width: 45px; text-align: center; }}
        .method-get {{ background: #1e40af; color: #93c5fd; }}
        .method-post {{ background: #166534; color: #86efac; }}
        .badge {{ display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 0.75em; font-weight: bold; margin-right: 8px; }}
        .footer {{ text-align: center; padding: 30px; color: #64748b; border-top: 1px solid #334155; margin-top: 40px; }}
        .tech-tag {{ display: inline-block; padding: 5px 15px; margin: 3px; background: #1e40af; color: #93c5fd; border-radius: 20px; font-size: 0.85em; }}
        .file-item {{ padding: 10px; background: #0f172a; border-radius: 8px; font-family: 'Courier New', monospace; margin-bottom: 5px; }}
        .waf-warning {{ padding: 20px; background: #7f1d1d; border: 1px solid #ef4444; border-radius: 12px; margin-bottom: 20px; }}
        .waf-safe {{ padding: 20px; background: #14532d; border: 1px solid #22c55e; border-radius: 12px; margin-bottom: 20px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🐛 Bug Hunter Security Report</h1>
            <div class="subtitle">Comprehensive Automated Security Assessment</div>
            <div class="meta">
                <span>📅 {scan_info.get('timestamp', 'N/A')}</span>
                <span>🎯 Target: {scan_info.get('command', 'N/A')[:60]}</span>
                <span>🛠️ Bug Hunter v2.0</span>
            </div>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card"><div class="number" style="color: #60a5fa;">{len(endpoints)}</div><div class="label">🔗 Endpoints</div></div>
            <div class="stat-card"><div class="number" style="color: #f87171;">{len(real_vulns)}</div><div class="label">⚠️ Vulnerabilities</div></div>
            <div class="stat-card"><div class="number" style="color: #34d399;">{len(open_ports) if open_ports else 0}</div><div class="label">🌐 Open Ports</div></div>
            <div class="stat-card"><div class="number" style="color: #a78bfa;">{len(sensitive_files) if sensitive_files else 0}</div><div class="label">🗂️ Sensitive Files</div></div>
            <div class="stat-card"><div class="number" style="color: #fbbf24;">{len(directories) if directories else 0}</div><div class="label">📂 Directories</div></div>
        </div>
"""
        
        # WAF Detection
        html += '<div class="section"><h2>🛡️ WAF Detection</h2>'
        if waf:
            html += f'<div class="waf-warning">⚠️ Web Application Firewall Detected: <strong>{waf}</strong></div>'
        else:
            html += '<div class="waf-safe">✅ No WAF Detected</div>'
        html += '</div>'
        
        # Technologies
        if technologies:
            html += '<div class="section"><h2>🔍 Technologies Detected</h2>'
            total_tech = 0
            for category, techs in technologies.items():
                if techs:
                    total_tech += len(techs)
                    html += f'<h3 style="color: #94a3b8; margin: 10px 0;">{category}:</h3>'
                    for tech in techs:
                        html += f'<span class="tech-tag">{tech}</span>'
            html += f'<p style="margin-top: 15px; color: #64748b;">Total: {total_tech} technologies</p></div>'
        
        # Vulnerabilities
        html += '<div class="section"><h2>🔴 Vulnerabilities</h2>'
        if real_vulns:
            for vuln in real_vulns:
                severity, color = get_severity(vuln)
                html += f'<div class="vuln-card" style="border-left-color: {color};"><span class="badge" style="background: {color}30; color: {color};">{severity.upper()}</span>{vuln}</div>'
        else:
            html += '<p style="color: #22c55e;">✅ No vulnerabilities detected</p>'
        html += '</div>'
        
        # Sensitive Files
        html += '<div class="section"><h2>🗂️ Sensitive Files</h2>'
        if sensitive_files:
            accessible = [f for f in sensitive_files if f.get('status') == 200]
            restricted = [f for f in sensitive_files if f.get('status') in [301, 302, 403]]
            if accessible:
                html += f'<p style="color: #ef4444;">🔴 Accessible Files ({len(accessible)}):</p>'
                for f in accessible:
                    html += f'<div class="file-item">📄 {f["url"]}</div>'
            if restricted:
                html += f'<p style="color: #fbbf24;">🟡 Restricted Files ({len(restricted)}):</p>'
                for f in restricted:
                    html += f'<div class="file-item">🔒 {f["url"]} (Status: {f["status"]})</div>'
        else:
            html += '<p style="color: #22c55e;">✅ No sensitive files found</p>'
        html += '</div>'
        
        # Directories
        html += '<div class="section"><h2>📂 Discovered Directories</h2>'
        if directories:
            for d in directories[:50]:
                html += f'<div class="file-item">📁 {d["url"]} (Status: {d["status"]})</div>'
            if len(directories) > 50:
                html += f'<p style="color: #64748b;">... and {len(directories) - 50} more</p>'
        else:
            html += '<p style="color: #22c55e;">✅ No directories found</p>'
        html += '</div>'
        
        # Endpoints
        html += '<div class="section"><h2>🔗 Discovered Endpoints</h2>'
        if endpoints:
            for endpoint in endpoints[:100]:
                method = 'POST' if any(x in endpoint.lower() for x in ['login', 'signup', 'register', 'submit', 'upload']) else 'GET'
                html += f'<div class="endpoint-item"><span class="method-badge method-{method.lower()}">{method}</span>{endpoint[:120]}</div>'
            if len(endpoints) > 100:
                html += f'<p style="color: #64748b;">... and {len(endpoints) - 100} more endpoints</p>'
        else:
            html += '<p style="color: #22c55e;">✅ No endpoints discovered</p>'
        html += '</div>'
        
        # Open Ports
        html += '<div class="section"><h2>🌐 Open Ports</h2>'
        if open_ports:
            for port in open_ports:
                if '[+]' in port or 'Port' in port:
                    html += f'<div class="file-item">🔌 {port}</div>'
        else:
            html += '<p style="color: #22c55e;">✅ No open ports data</p>'
        html += '</div>'
        
        html += f"""
        <div class="footer">
            <p>🐛 Bug Hunter Swiss Knife v2.0 | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p>⚠️ Automated scan - Manual verification recommended</p>
        </div>
    </div>
</body>
</html>
"""
        
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(html)
        
        return filename