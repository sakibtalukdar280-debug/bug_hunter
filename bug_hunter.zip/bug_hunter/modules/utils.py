"""
Utility functions for Bug Hunter
"""

import re
import os
from urllib.parse import urlparse

def load_cookies(cookie_string):
    """Parse cookie string into dictionary"""
    cookies = {}
    if cookie_string:
        for cookie in cookie_string.split(';'):
            cookie = cookie.strip()
            if '=' in cookie:
                key, value = cookie.split('=', 1)
                cookies[key.strip()] = value.strip()
    return cookies

def validate_url(url):
    """Validate URL format"""
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except:
        return False

def sanitize_filename(filename):
    """Remove invalid characters from filename"""
    return re.sub(r'[<>:"/\\|?*]', '_', filename)

def get_severity_color(severity):
    """Return ANSI color code based on severity"""
    colors = {
        'critical': '\033[91m',
        'high': '\033[93m',
        'medium': '\033[94m',
        'low': '\033[92m',
        'info': '\033[97m',
    }
    return colors.get(severity.lower(), '\033[97m')

def truncate_string(text, max_length=100):
    """Truncate string to max length"""
    if len(text) <= max_length:
        return text
    return text[:max_length] + '...'

def is_same_domain(url1, url2):
    """Check if two URLs belong to same domain"""
    try:
        domain1 = urlparse(url1).netloc
        domain2 = urlparse(url2).netloc
        return domain1 == domain2
    except:
        return False

def extract_params_from_url(url):
    """Extract parameter names from URL"""
    params = []
    if '?' in url:
        query = url.split('?', 1)[1]
        for param in query.split('&'):
            if '=' in param:
                params.append(param.split('=')[0])
    return params

def load_wordlist(filename):
    """Load wordlist from file"""
    wordlist_path = os.path.join('wordlists', filename)
    if os.path.exists(wordlist_path):
        with open(wordlist_path, 'r', encoding='utf-8') as f:
            return [line.strip() for line in f if line.strip() and not line.startswith('#')]
    return []