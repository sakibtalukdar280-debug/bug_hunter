import requests
from colorama import Fore, Style
import urllib3
from urllib.parse import urljoin

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class WAFDetector:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        if 'User-Agent' not in self.session.headers:
            self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        # WAF signatures
        self.waf_signatures = {
            'Cloudflare': ['cloudflare', '__cfduid', 'cf-ray', 'cf-cache-status'],
            'AWS WAF': ['aws', 'awselb', 'x-amz-cf-id'],
            'Akamai': ['akamai', 'akamaighost'],
            'Imperva': ['imperva', 'incapsula', '_incap_'],
            'Sucuri': ['sucuri', 'sucuricloudproxy'],
            'F5 BIG-IP': ['f5', 'big-ip', 'bigipserver'],
            'ModSecurity': ['mod_security', 'modsecurity'],
            'Barracuda': ['barracuda', 'barra'],
            'Fortinet': ['fortinet', 'fortiweb'],
            'Citrix NetScaler': ['citrix', 'netscaler', 'ns_af'],
            'Wordfence': ['wordfence'],
            'DDoS-Guard': ['ddos-guard'],
            'StackPath': ['stackpath'],
            'Radware': ['radware'],
            'Wallarm': ['wallarm'],
        }
        
        self.detected_waf = None
        self.waf_evidence = []
    
    def detect(self):
        """Detect WAF presence"""
        if self.verbose:
            print(f"\n{Fore.CYAN}[*] Detecting WAF on: {self.url}{Style.RESET_ALL}")
        
        try:
            # Normal request
            response = self.session.get(self.url, timeout=10)
            headers = response.headers
            
            # Check headers for WAF signatures
            all_headers = ' '.join([f"{k}: {v}" for k, v in headers.items()]).lower()
            
            for waf_name, signatures in self.waf_signatures.items():
                for sig in signatures:
                    if sig.lower() in all_headers:
                        self.detected_waf = waf_name
                        self.waf_evidence.append(f"Header: {sig}")
                        break
                if self.detected_waf:
                    break
            
            # If not found in headers, try malicious request
            if not self.detected_waf:
                malicious_url = f"{self.url}/?id=1' OR '1'='1"
                try:
                    mal_response = self.session.get(malicious_url, timeout=10)
                    
                    # Check response for WAF blocks
                    if mal_response.status_code in [403, 406, 429, 501, 503]:
                        block_indicators = [
                            'blocked', 'forbidden', 'access denied',
                            'waf', 'firewall', 'security',
                            'ddos', 'attack', 'malicious'
                        ]
                        
                        response_text = mal_response.text.lower()
                        for indicator in block_indicators:
                            if indicator in response_text:
                                self.detected_waf = 'Generic WAF'
                                self.waf_evidence.append(f"Blocked request: {indicator}")
                                break
                except:
                    pass
            
            if self.verbose:
                if self.detected_waf:
                    print(f"  {Fore.RED}[✓]{Style.RESET_ALL} WAF Detected: {self.detected_waf}")
                else:
                    print(f"  {Fore.GREEN}[✓]{Style.RESET_ALL} No WAF detected")
            
            return self.detected_waf
            
        except Exception as e:
            if self.verbose:
                print(f"{Fore.RED}[✗] Error: {e}{Style.RESET_ALL}")
            return None
    
    def display_results(self):
        """Display WAF detection results"""
        print(f"\n{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
        print(f"{Fore.YELLOW}  🛡️ WAF DETECTION RESULTS{Style.RESET_ALL}")
        print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}")
        
        if self.detected_waf:
            print(f"\n{Fore.RED}  ⚠️  WAF Detected: {self.detected_waf}{Style.RESET_ALL}")
            if self.waf_evidence:
                print(f"\n{Fore.YELLOW}  Evidence:{Style.RESET_ALL}")
                for evidence in self.waf_evidence:
                    print(f"    • {evidence}")
        else:
            print(f"\n{Fore.GREEN}  ✅ No WAF detected{Style.RESET_ALL}")
        
        print(f"{Fore.CYAN}{'='*50}{Style.RESET_ALL}")