import requests
import re
from urllib.parse import urljoin
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class EmailHarvester:
    def __init__(self, url, depth=2, config=None):
        self.url = url.rstrip('/')
        self.depth = depth
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.emails = set()
        self.visited = set()
    
    def extract_emails(self, text):
        """Extract email addresses from text"""
        # Email regex pattern
        pattern = r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        return set(re.findall(pattern, text))
    
    def extract_links(self, html, base_url):
        """Extract links for crawling"""
        pattern = r'href=["\']([^"\']+)["\']'
        links = re.findall(pattern, html)
        absolute_links = []
        for link in links:
            if not link.startswith(('http://', 'https://')):
                link = urljoin(base_url, link)
            if base_url in link:
                absolute_links.append(link)
        return absolute_links
    
    def harvest(self):
        """Harvest emails from website"""
        if self.verbose:
            print(f"\n[*] Harvesting emails from: {self.url}")
            print(f"[*] Crawl depth: {self.depth}")
        
        to_visit = [(self.url, 0)]
        
        while to_visit:
            url, current_depth = to_visit.pop(0)
            
            if url in self.visited or current_depth > self.depth:
                continue
            
            self.visited.add(url)
            
            try:
                if self.verbose:
                    print(f"  [*] Scanning: {url[:80]}")
                
                response = self.session.get(url, timeout=10)
                
                # Extract emails
                emails = self.extract_emails(response.text)
                self.emails.update(emails)
                
                if emails and self.verbose:
                    for email in emails:
                        print(f"    [✓] Found: {email}")
                
                # Extract links for further crawling
                if current_depth < self.depth:
                    links = self.extract_links(response.text, url)
                    for link in links:
                        if link not in self.visited:
                            to_visit.append((link, current_depth + 1))
                
            except Exception as e:
                if self.verbose:
                    print(f"    [✗] Error: {e}")
                continue
        
        return list(self.emails)
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  📧 EMAIL HARVESTER RESULTS")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        print(f"  Pages scanned: {len(self.visited)}")
        print(f"  Emails found: {len(self.emails)}")
        
        if self.emails:
            print(f"\n  Found Emails:")
            for email in sorted(self.emails):
                print(f"    • {email}")
        else:
            print(f"\n  No emails found")
        
        print(f"{'='*50}")
