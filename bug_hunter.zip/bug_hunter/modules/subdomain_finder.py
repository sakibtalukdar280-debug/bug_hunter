import requests
import concurrent.futures
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class SubdomainFinder:
    def __init__(self, domain, threads=30, config=None):
        self.domain = domain.replace('https://', '').replace('http://', '').rstrip('/')
        self.threads = threads
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        # Common subdomains
        self.subdomains = [
            'www', 'mail', 'ftp', 'localhost', 'webmail', 'smtp', 'pop',
            'ns1', 'ns2', 'dns', 'dns1', 'dns2',
            'admin', 'administrator', 'panel', 'control',
            'blog', 'blogs', 'news', 'media', 'press',
            'dev', 'development', 'test', 'testing', 'staging',
            'api', 'api-v1', 'api-v2', 'api-v3',
            'app', 'apps', 'app1', 'app2',
            'mobile', 'm', 'mob',
            'shop', 'store', 'market', 'pay',
            'cdn', 'cdn1', 'cdn2', 'static', 'assets',
            'images', 'img', 'videos', 'video',
            'docs', 'documentation', 'wiki', 'help', 'support',
            'secure', 'ssl', 'security',
            'vpn', 'proxy', 'gateway',
            'db', 'database', 'sql', 'mysql',
            'git', 'svn', 'repo',
            'jenkins', 'ci', 'cd', 'build',
            'monitor', 'monitoring', 'status', 'health',
            'analytics', 'tracking', 'stats',
            'crm', 'erp', 'portal', 'partner', 'partners',
            'career', 'careers', 'jobs', 'hr',
            'forum', 'forums', 'community',
            'chat', 'messenger', 'im',
            'remote', 'rds', 'vnc',
            'sandbox', 'beta', 'alpha',
            'old', 'new', 'v1', 'v2',
            'internal', 'intranet', 'corp', 'corporate',
            'auth', 'sso', 'login', 'signin',
            'download', 'downloads', 'upload', 'uploads',
            'email', 'webmail', 'owa',
            'cloud', 'host', 'hosting',
            'backup', 'backups', 'replica',
        ]
        
        self.found_subdomains = []
    
    def check_subdomain(self, subdomain):
        """Check if subdomain exists"""
        url = f"https://{subdomain}.{self.domain}"
        try:
            response = self.session.get(url, timeout=5, allow_redirects=True)
            if response.status_code < 500:
                return {
                    'url': url,
                    'status': response.status_code,
                    'size': len(response.content),
                    'server': response.headers.get('Server', 'Unknown')
                }
        except:
            try:
                url = f"http://{subdomain}.{self.domain}"
                response = self.session.get(url, timeout=5, allow_redirects=True)
                if response.status_code < 500:
                    return {
                        'url': url,
                        'status': response.status_code,
                        'size': len(response.content),
                        'server': response.headers.get('Server', 'Unknown')
                    }
            except:
                pass
        return None
    
    def scan(self):
        """Scan for subdomains"""
        if self.verbose:
            print(f"\n[*] Finding subdomains for: {self.domain}")
            print(f"[*] Checking {len(self.subdomains)} subdomains, Threads: {self.threads}\n")
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(self.check_subdomain, sub): sub 
                      for sub in self.subdomains}
            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    self.found_subdomains.append(result)
                    if self.verbose:
                        print(f"  [✓] {result['url']} (Status: {result['status']})")
        
        return self.found_subdomains
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🌐 SUBDOMAIN FINDER RESULTS")
        print(f"{'='*50}")
        print(f"  Domain: {self.domain}")
        print(f"  Found: {len(self.found_subdomains)} subdomains")
        
        if self.found_subdomains:
            # Sort by status
            self.found_subdomains.sort(key=lambda x: x['status'])
            
            print(f"\n  Discovered Subdomains:")
            for sub in self.found_subdomains:
                icon = "🟢" if sub['status'] == 200 else "🟡"
                print(f"    {icon} {sub['url']} ({sub['status']})")
        
        print(f"{'='*50}")
