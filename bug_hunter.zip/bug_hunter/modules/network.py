import socket
import concurrent.futures
from colorama import Fore, Style
import time

class NetworkScanner:
    def __init__(self, host, port_range=(1, 1000), config=None):
        self.host = host
        self.start_port, self.end_port = port_range
        self.verbose = config.get('verbose', False) if config else False
        self.threads = config.get('threads', 100) if config else 100
        self.config = config if config else {}
        self.open_ports = []
        
        self.services = {
            20: 'FTP Data', 21: 'FTP Control', 22: 'SSH', 23: 'Telnet',
            25: 'SMTP', 53: 'DNS', 80: 'HTTP', 110: 'POP3', 111: 'RPC',
            135: 'RPC', 139: 'NetBIOS', 143: 'IMAP', 443: 'HTTPS',
            445: 'SMB', 993: 'IMAPS', 995: 'POP3S', 1723: 'PPTP',
            3306: 'MySQL', 3389: 'RDP', 5900: 'VNC', 8080: 'HTTP-Proxy',
            8443: 'HTTPS-Alt', 27017: 'MongoDB', 6379: 'Redis',
            11211: 'Memcached', 5432: 'PostgreSQL', 1521: 'Oracle',
            1433: 'MSSQL', 27017: 'MongoDB', 9200: 'Elasticsearch',
            6379: 'Redis', 11211: 'Memcached',
        }
    
    def scan_port(self, port):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex((self.host, port))
            sock.close()
            
            if result == 0:
                service = self.services.get(port, 'Unknown')
                return port, service
        except:
            pass
        return None
    
    def scan(self):
        if self.verbose:
            print(f"{Fore.BLUE}[*] Scanning {self.host} ports {self.start_port}-{self.end_port}{Style.RESET_ALL}")
        
        start_time = time.time()
        total_ports = self.end_port - self.start_port + 1
        
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.threads) as executor:
            futures = {executor.submit(self.scan_port, port): port 
                      for port in range(self.start_port, self.end_port + 1)}
            
            completed = 0
            for future in concurrent.futures.as_completed(futures):
                completed += 1
                result = future.result()
                if result:
                    port, service = result
                    self.open_ports.append(f"[+] Port {port}: {service}")
                    if self.verbose:
                        print(f"{Fore.GREEN}[✓] Open: {port}/tcp - {service}{Style.RESET_ALL}")
                
                if self.verbose and completed % 100 == 0:
                    progress = (completed / total_ports) * 100
                    print(f"{Fore.CYAN}[*] Progress: {progress:.1f}% ({completed}/{total_ports}){Style.RESET_ALL}")
        
        elapsed = time.time() - start_time
        
        self.open_ports.append(f"\n[*] Scan completed in {elapsed:.2f} seconds")
        self.open_ports.append(f"[*] Found {len(self.open_ports)-2} open ports out of {total_ports} scanned")
        
        return self.open_ports