import requests
from urllib.parse import urljoin
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class DirListingChecker:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        self.common_dirs = [
            'uploads', 'images', 'img', 'css', 'js', 'assets',
            'files', 'downloads', 'backup', 'backups', 'tmp', 'temp',
            'logs', 'log', 'admin', 'wp-content', 'wp-includes',
            'static', 'media', 'data', 'docs', 'documentation',
        ]
        
        self.listing_found = []
        self.dir_listing_signatures = [
            'Index of /',
            'Directory Listing',
            'Parent Directory',
            '[To Parent Directory]',
            '<title>Index of',
            'Last modified</a>',
        ]
    
    def check_directory(self, directory):
        """Check if directory has listing enabled"""
        try:
            full_url = urljoin(self.url + '/', directory) + '/'
            response = self.session.get(full_url, timeout=10)
            
            if response.status_code == 200:
                for sig in self.dir_listing_signatures:
                    if sig.lower() in response.text.lower():
                        return {
                            'url': full_url,
                            'status': response.status_code,
                            'signature': sig
                        }
        except:
            pass
        return None
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Checking directory listing: {self.url}")
            print(f"[*] Testing {len(self.common_dirs)} directories\n")
        
        for directory in self.common_dirs:
            result = self.check_directory(directory)
            if result:
                self.listing_found.append(result)
                if self.verbose:
                    print(f"  {Fore.RED}[⚠] LISTING ENABLED: {result['url']}{Style.RESET_ALL}")
            elif self.verbose:
                print(f"  [✓] Safe: /{directory}/")
        
        return self.listing_found
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  📂 DIRECTORY LISTING CHECK")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        
        if self.listing_found:
            print(f"\n  {Fore.RED}🔴 DIRECTORY LISTING ENABLED! ({len(self.listing_found)}){Style.RESET_ALL}")
            print(f"  This exposes file structure to attackers.\n")
            for item in self.listing_found:
                print(f"    • {item['url']}")
                print(f"      Signature: {item['signature']}")
        else:
            print(f"\n  ✅ No directory listing found")
        
        print(f"{'='*50}")
