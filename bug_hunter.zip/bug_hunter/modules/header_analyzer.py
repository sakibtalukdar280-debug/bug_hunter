import requests
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class HeaderAnalyzer:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        # Security headers to check
        self.security_headers = {
            'Strict-Transport-Security': {
                'importance': 'High',
                'description': 'HTTP Strict Transport Security (HSTS)',
                'recommended': 'max-age=31536000; includeSubDomains'
            },
            'Content-Security-Policy': {
                'importance': 'High',
                'description': 'Content Security Policy (CSP)',
                'recommended': "default-src 'self'"
            },
            'X-Frame-Options': {
                'importance': 'Medium',
                'description': 'Prevents clickjacking attacks',
                'recommended': 'DENY or SAMEORIGIN'
            },
            'X-Content-Type-Options': {
                'importance': 'Medium',
                'description': 'Prevents MIME type sniffing',
                'recommended': 'nosniff'
            },
            'Referrer-Policy': {
                'importance': 'Medium',
                'description': 'Controls referrer information',
                'recommended': 'strict-origin-when-cross-origin'
            },
            'Permissions-Policy': {
                'importance': 'Low',
                'description': 'Controls browser features',
                'recommended': 'geolocation=(), microphone=()'
            },
            'X-XSS-Protection': {
                'importance': 'Low',
                'description': 'XSS filter (deprecated)',
                'recommended': '1; mode=block'
            },
            'Access-Control-Allow-Origin': {
                'importance': 'Medium',
                'description': 'CORS policy',
                'recommended': 'Specific origin, not *'
            },
            'Server': {
                'importance': 'Info',
                'description': 'Server information disclosure',
                'recommended': 'Should be hidden'
            },
            'X-Powered-By': {
                'importance': 'Info',
                'description': 'Technology disclosure',
                'recommended': 'Should be hidden'
            },
        }
        
        self.headers = {}
        self.missing_headers = []
        self.info_disclosure = []
        self.security_score = 0
    
    def analyze(self):
        if self.verbose:
            print(f"\n[*] Analyzing security headers for: {self.url}")
        
        try:
            response = self.session.get(self.url, timeout=10)
            self.headers = dict(response.headers)
            
            # Check each security header
            for header, info in self.security_headers.items():
                if header not in self.headers:
                    if info['importance'] != 'Info':
                        self.missing_headers.append({
                            'header': header,
                            'importance': info['importance'],
                            'description': info['description'],
                            'recommended': info['recommended']
                        })
                else:
                    # Check for info disclosure
                    if header in ['Server', 'X-Powered-By']:
                        self.info_disclosure.append({
                            'header': header,
                            'value': self.headers[header]
                        })
                    
                    if self.verbose:
                        print(f"  [✓] {header}: {self.headers[header][:50]}")
            
            # Calculate security score
            total_high = sum(1 for h in self.security_headers if self.security_headers[h]['importance'] == 'High')
            total_medium = sum(1 for h in self.security_headers if self.security_headers[h]['importance'] == 'Medium')
            
            present_high = sum(1 for h in self.security_headers 
                             if self.security_headers[h]['importance'] == 'High' and h in self.headers)
            present_medium = sum(1 for h in self.security_headers 
                               if self.security_headers[h]['importance'] == 'Medium' and h in self.headers)
            
            self.security_score = int((present_high * 3 + present_medium * 2) / (total_high * 3 + total_medium * 2) * 100)
            
            return self.headers
            
        except Exception as e:
            if self.verbose:
                print(f"[✗] Error: {e}")
            return {}
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🔒 SECURITY HEADER ANALYSIS")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        print(f"  Security Score: {self.security_score}/100")
        
        # Score bar
        bar = "█" * (self.security_score // 10) + "░" * (10 - self.security_score // 10)
        color = Fore.RED if self.security_score < 50 else Fore.YELLOW if self.security_score < 80 else Fore.GREEN
        print(f"  {color}[{bar}]{Style.RESET_ALL}")
        
        if self.missing_headers:
            print(f"\n  🔴 Missing Security Headers:")
            for mh in self.missing_headers:
                print(f"    • {Fore.RED}{mh['header']}{Style.RESET_ALL} ({mh['importance']})")
                print(f"      {mh['description']}")
                print(f"      Recommended: {mh['recommended']}")
        
        if self.info_disclosure:
            print(f"\n  🟡 Information Disclosure:")
            for info in self.info_disclosure:
                print(f"    • {info['header']}: {info['value'][:50]}")
        
        if not self.missing_headers and not self.info_disclosure:
            print(f"\n  ✅ All security headers are present!")
        
        print(f"\n  📋 Present Headers:")
        for header, value in self.headers.items():
            if 'security' in header.lower() or header.startswith('X-') or header.startswith('Content-'):
                print(f"    • {header}: {value[:80]}")
        
        print(f"{'='*50}")
