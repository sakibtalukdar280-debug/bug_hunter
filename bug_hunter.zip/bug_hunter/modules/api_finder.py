import requests
import re
from urllib.parse import urljoin
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class APIFinder:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        self.api_patterns = [
            r'/api/v\d+/[a-zA-Z]+',
            r'/api/[a-zA-Z]+',
            r'/rest/v\d+/[a-zA-Z]+',
            r'/graphql',
            r'/swagger',
            r'/openapi',
            r'/docs/api',
            r'/api-docs',
            r'/v\d+/[a-zA-Z]+',
            r'/services/[a-zA-Z]+',
        ]
        
        self.api_endpoints = []
        self.graphql_found = False
        self.swagger_found = False
    
    def extract_from_js(self, js_content, js_url):
        """Extract API endpoints from JavaScript"""
        patterns = [
            r'(?:fetch|axios|ajax|http\.get|http\.post)\s*\(\s*["\']([^"\']+)["\']',
            r'(?:baseURL|apiUrl|API_URL|api|endpoint)\s*[:=]\s*["\']([^"\']+)["\']',
            r'["\'](/api/[^"\']+)["\']',
            r'["\'](/v\d+/[^"\']+)["\']',
            r'["\'](/graphql[^"\']*)["\']',
        ]
        
        endpoints = []
        for pattern in patterns:
            matches = re.findall(pattern, js_content, re.IGNORECASE)
            for match in matches:
                if isinstance(match, tuple):
                    match = match[0]
                if match.startswith('/'):
                    endpoints.append(urljoin(self.url, match))
                elif match.startswith('http'):
                    endpoints.append(match)
        
        return endpoints
    
    def discover(self):
        if self.verbose:
            print(f"\n[*] Discovering API endpoints: {self.url}")
        
        try:
            # Get main page
            response = self.session.get(self.url, timeout=10)
            html = response.text
            
            # Check for GraphQL
            graphql_url = urljoin(self.url, '/graphql')
            try:
                gql_resp = self.session.get(graphql_url, timeout=5)
                if gql_resp.status_code in [200, 400]:
                    self.graphql_found = True
                    self.api_endpoints.append(f"GraphQL: {graphql_url}")
                    if self.verbose:
                        print(f"  {Fore.GREEN}[✓] GraphQL: {graphql_url}{Style.RESET_ALL}")
            except:
                pass
            
            # Check for Swagger/OpenAPI
            swagger_urls = ['/swagger.json', '/swagger.yaml', '/openapi.json', '/api-docs', '/api/docs', '/docs/api']
            for sw_url in swagger_urls:
                try:
                    sw_full = urljoin(self.url, sw_url)
                    sw_resp = self.session.get(sw_full, timeout=5)
                    if sw_resp.status_code == 200:
                        self.swagger_found = True
                        self.api_endpoints.append(f"Swagger: {sw_full}")
                        if self.verbose:
                            print(f"  {Fore.GREEN}[✓] Swagger: {sw_full}{Style.RESET_ALL}")
                        break
                except:
                    pass
            
            # Extract API endpoints from HTML
            for pattern in self.api_patterns:
                matches = re.findall(pattern, html, re.IGNORECASE)
                for match in matches:
                    full_url = urljoin(self.url, match)
                    if full_url not in self.api_endpoints:
                        self.api_endpoints.append(full_url)
            
            # Extract from JavaScript files
            js_pattern = r'<script[^>]+src=["\']([^"\']+\.js[^"\']*)["\']'
            js_files = re.findall(js_pattern, html, re.IGNORECASE)
            
            for js_file in js_files:
                js_url = urljoin(self.url, js_file)
                try:
                    js_resp = self.session.get(js_url, timeout=10)
                    api_endpoints = self.extract_from_js(js_resp.text, js_url)
                    for ep in api_endpoints:
                        if ep not in self.api_endpoints:
                            self.api_endpoints.append(ep)
                            if self.verbose:
                                print(f"  {Fore.GREEN}[✓] API: {ep}{Style.RESET_ALL}")
                except:
                    pass
            
            return self.api_endpoints
            
        except Exception as e:
            if self.verbose:
                print(f"[✗] Error: {e}")
            return []
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🔌 API ENDPOINT DISCOVERY")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        print(f"  GraphQL: {'✅ Found' if self.graphql_found else '❌ Not found'}")
        print(f"  Swagger: {'✅ Found' if self.swagger_found else '❌ Not found'}")
        print(f"  API Endpoints: {len(self.api_endpoints)}")
        
        if self.api_endpoints:
            print(f"\n  Discovered Endpoints:")
            for ep in self.api_endpoints:
                icon = "🔌" if 'graphql' in ep.lower() else "📄" if 'swagger' in ep.lower() else "🔗"
                print(f"    {icon} {ep}")
        
        print(f"{'='*50}")
