import requests
from urllib.parse import urljoin, urlencode
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class OpenRedirectDetector:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        self.redirect_params = [
            'redirect', 'url', 'next', 'return', 'goto', 'target',
            'redir', 'redirect_uri', 'redirect_url', 'return_url',
            'return_to', 'redirect_to', 'link', 'forward', 'destination',
            'continue', 'origin', 'source', 'ref', 'referrer',
        ]
        
        self.payloads = [
            'https://evil.com',
            '//evil.com',
            '\\\\evil.com',
            'https:evil.com',
            'https://evil.com/%2F..',
            'https://evil.com#',
            'https://evil.com?',
            'javascript:alert(1)',
            'data:text/html,<script>alert(1)</script>',
        ]
        
        self.vulnerable = []
    
    def test_redirect(self, param, payload):
        """Test a single redirect parameter"""
        try:
            test_url = f"{self.url}?{param}={payload}"
            response = self.session.get(test_url, timeout=10, allow_redirects=False)
            
            if response.status_code in [301, 302, 303, 307, 308]:
                location = response.headers.get('Location', '')
                
                # Check if redirect is to our payload
                if 'evil.com' in location or 'javascript:' in location or 'data:' in location:
                    return {
                        'param': param,
                        'payload': payload,
                        'location': location,
                        'status': response.status_code
                    }
        except:
            pass
        return None
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Testing Open Redirect: {self.url}")
            print(f"[*] Testing {len(self.redirect_params)} params with {len(self.payloads)} payloads\n")
        
        for param in self.redirect_params:
            for payload in self.payloads:
                result = self.test_redirect(param, payload)
                if result:
                    self.vulnerable.append(result)
                    if self.verbose:
                        print(f"  {Fore.RED}[⚠] VULNERABLE: {param}={payload}{Style.RESET_ALL}")
                        print(f"       Redirects to: {result['location']}")
                    break  # Found vulnerability for this param, move to next
        
        return self.vulnerable
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🔀 OPEN REDIRECT DETECTOR")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        
        if self.vulnerable:
            print(f"\n  {Fore.RED}🔴 OPEN REDIRECT VULNERABLE! ({len(self.vulnerable)}){Style.RESET_ALL}\n")
            for v in self.vulnerable:
                print(f"    • Parameter: {v['param']}")
                print(f"      Payload: {v['payload']}")
                print(f"      Redirects to: {v['location']}")
                print()
        else:
            print(f"\n  ✅ No open redirect found")
        
        print(f"{'='*50}")
