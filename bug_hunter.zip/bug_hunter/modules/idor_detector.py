import requests
import re
from urllib.parse import urljoin
from colorama import Fore, Style
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class IDORDetector:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        if self.config.get('headers'):
            self.session.headers.update(self.config['headers'])
        
        # Patterns that suggest IDOR vulnerability
        self.idor_patterns = [
            (r'/(?:user|users|profile|account)/(\d+)', 'User ID'),
            (r'/(?:order|orders|invoice|payment)/(\d+)', 'Order ID'),
            (r'/(?:product|item|article|post)/(\d+)', 'Product/Post ID'),
            (r'/(?:file|document|upload|download)/(\d+)', 'File ID'),
            (r'/(?:admin|manage|edit)/(\d+)', 'Admin Resource'),
            (r'/(?:api|rest)/.*?/(\d+)', 'API Resource'),
            (r'[?&](?:id|user_id|uid|profile_id)=(\d+)', 'Query Parameter ID'),
            (r'[?&](?:order_id|invoice_id|payment_id)=(\d+)', 'Order Query ID'),
            (r'[?&](?:file|doc|document_id)=(\d+)', 'File Query ID'),
        ]
        
        self.potential_idor = []
        self.tested_results = []
    
    def find_idor_endpoints(self, html):
        """Find potential IDOR endpoints"""
        endpoints = []
        
        # Find all links
        links = re.findall(r'href=["\']([^"\']+)["\']', html)
        for link in links:
            full_url = urljoin(self.url, link)
            for pattern, id_type in self.idor_patterns:
                match = re.search(pattern, full_url, re.IGNORECASE)
                if match:
                    endpoints.append({
                        'url': full_url,
                        'type': id_type,
                        'id': match.group(1),
                        'pattern': pattern
                    })
        
        return endpoints
    
    def test_idor(self, url, original_id, id_type):
        """Test if changing ID gives access to another resource"""
        test_ids = []
        try:
            orig = int(original_id)
            test_ids = [str(orig + 1), str(orig - 1), '0', '1', '2']
        except:
            test_ids = ['1', '2', '0']
        
        results = []
        original_response = None
        
        try:
            original_response = self.session.get(url, timeout=10)
        except:
            pass
        
        for test_id in test_ids:
            test_url = re.sub(r'\d+', test_id, url, count=1)
            try:
                response = self.session.get(test_url, timeout=10)
                
                # If different ID returns similar response = possible IDOR
                if original_response:
                    if (response.status_code == original_response.status_code and
                        abs(len(response.content) - len(original_response.content)) < 100):
                        results.append({
                            'test_url': test_url,
                            'test_id': test_id,
                            'status': response.status_code,
                            'possible': True
                        })
            except:
                pass
        
        return results
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Detecting potential IDOR endpoints: {self.url}")
        
        try:
            response = self.session.get(self.url, timeout=10)
            self.potential_idor = self.find_idor_endpoints(response.text)
            
            if self.verbose:
                print(f"[*] Found {len(self.potential_idor)} potential IDOR endpoints\n")
            
            for endpoint in self.potential_idor[:10]:  # Test first 10
                if self.verbose:
                    print(f"  [*] Testing: {endpoint['url'][:80]}")
                
                results = self.test_idor(endpoint['url'], endpoint['id'], endpoint['type'])
                for result in results:
                    if result['possible']:
                        self.tested_results.append({
                            'original': endpoint['url'],
                            'test_url': result['test_url'],
                            'type': endpoint['type'],
                            'original_id': endpoint['id'],
                            'test_id': result['test_id']
                        })
                        if self.verbose:
                            print(f"    {Fore.RED}[⚠] Possible IDOR: {result['test_url']}{Style.RESET_ALL}")
            
            return self.potential_idor
            
        except Exception as e:
            if self.verbose:
                print(f"[✗] Error: {e}")
            return []
    
    def display_results(self):
        print(f"\n{'='*60}")
        print(f"  🔍 IDOR ENDPOINT DETECTION")
        print(f"{'='*60}")
        print(f"  URL: {self.url}")
        print(f"  Potential IDOR endpoints: {len(self.potential_idor)}")
        print(f"  Tested: {len(self.tested_results)} possible")
        
        if self.potential_idor:
            print(f"\n  📋 Potential IDOR Endpoints:")
            for ep in self.potential_idor[:20]:
                print(f"    • {ep['type']}: {ep['url'][:80]}")
                print(f"      ID: {ep['id']}")
        
        if self.tested_results:
            print(f"\n  {Fore.RED}⚠️  Possible IDOR Found:{Style.RESET_ALL}")
            for t in self.tested_results:
                print(f"    • Original: {t['original_id']} → Test: {t['test_id']}")
                print(f"      {t['test_url'][:80]}")
        
        print(f"{'='*60}")
