import requests
import re
from urllib.parse import urljoin
from colorama import Fore, Style
import concurrent.futures
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class LinkChecker:
    def __init__(self, url, config=None):
        self.url = url.rstrip('/')
        self.verbose = config.get('verbose', False) if config else False
        self.config = config if config else {}
        self.session = requests.Session()
        self.session.verify = False
        self.session.headers['User-Agent'] = 'BugHunter/2.0'
        
        self.links = set()
        self.broken_links = []
        self.working_links = []
        self.redirect_links = []
    
    def extract_links(self, html):
        """Extract all links from HTML"""
        pattern = r'href=["\']([^"\']+)["\']'
        return re.findall(pattern, html)
    
    def check_link(self, link_data):
        """Check if a link is working"""
        link, source = link_data
        
        try:
            full_url = link
            if not link.startswith(('http://', 'https://')):
                full_url = urljoin(self.url, link)
            
            response = self.session.head(full_url, timeout=10, allow_redirects=True)
            
            if response.status_code == 200:
                return {'url': full_url, 'status': 'working', 'code': 200, 'source': source}
            elif response.status_code in [301, 302, 303, 307, 308]:
                return {'url': full_url, 'status': 'redirect', 'code': response.status_code, 'source': source}
            else:
                return {'url': full_url, 'status': 'broken', 'code': response.status_code, 'source': source}
        except:
            return {'url': full_url, 'status': 'broken', 'code': 0, 'source': source}
    
    def scan(self):
        if self.verbose:
            print(f"\n[*] Checking links on: {self.url}")
        
        try:
            # Get page
            response = self.session.get(self.url, timeout=10)
            raw_links = self.extract_links(response.text)
            
            # Filter links
            links_to_check = []
            for link in raw_links:
                if not link.startswith(('#', 'javascript:', 'mailto:', 'tel:')):
                    links_to_check.append((link, self.url))
                    self.links.add(link)
            
            if self.verbose:
                print(f"[*] Found {len(links_to_check)} links to check\n")
            
            # Check links with threading
            with concurrent.futures.ThreadPoolExecutor(max_workers=20) as executor:
                futures = {executor.submit(self.check_link, ld): ld for ld in links_to_check}
                
                for future in concurrent.futures.as_completed(futures):
                    result = future.result()
                    if result['status'] == 'working':
                        self.working_links.append(result)
                    elif result['status'] == 'redirect':
                        self.redirect_links.append(result)
                    else:
                        self.broken_links.append(result)
                    
                    if self.verbose:
                        icon = "✓" if result['status'] == 'working' else "↪" if result['status'] == 'redirect' else "✗"
                        print(f"  [{icon}] {result['url'][:70]} ({result['code']})")
            
            return self.links
            
        except Exception as e:
            if self.verbose:
                print(f"[✗] Error: {e}")
            return set()
    
    def display_results(self):
        print(f"\n{'='*50}")
        print(f"  🔗 LINK CHECKER RESULTS")
        print(f"{'='*50}")
        print(f"  URL: {self.url}")
        print(f"  Total Links: {len(self.links)}")
        print(f"  Working: {len(self.working_links)}")
        print(f"  Redirects: {len(self.redirect_links)}")
        print(f"  Broken: {len(self.broken_links)}")
        
        if self.broken_links:
            print(f"\n  🔴 Broken Links:")
            for link in self.broken_links[:20]:
                print(f"    • {link['url'][:80]} (Code: {link['code']})")
        
        if self.redirect_links:
            print(f"\n  🟡 Redirect Links (first 10):")
            for link in self.redirect_links[:10]:
                print(f"    • {link['url'][:80]} (Code: {link['code']})")
        
        print(f"{'='*50}")
